<?php

$googleConfig = array();
$googleConfig['client_id'] = "819644135058-kcmf6pvbcqtbicufib6t4uan475d39d9.apps.googleusercontent.com";
$googleConfig['client_secret'] = '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';

?>