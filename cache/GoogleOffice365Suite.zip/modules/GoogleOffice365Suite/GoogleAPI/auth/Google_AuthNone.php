<?php
/**
 *
 * @ IonCube v8.3 Loader By DoraemonPT
 * @ PHP 5.3
 * @ Decoder version : 1.0.0.7
 * @ Author     : DoraemonPT
 * @ Release on : 09.05.2014
 * @ Website    : http://EasyToYou.eu
 *
 **/

class Google_AuthNone extends Google_Auth {
	var $key = null;

	function __construct() {
		global $apiConfig;

		if (!empty( $apiConfig['developer_key'] )) {
			$this->setDeveloperKey($apiConfig['developer_key']);
		}
	}

	function setDeveloperKey($key) {
		$this->key = $key;
	}

	function authenticate($service) {
	}

	function setAccessToken($accessToken) {
	}

	function getAccessToken() {
	}

	function createAuthUrl($scope) {
	}

	function refreshToken($refreshToken) {
	}

	function revokeToken() {
	}

	function sign(Google_HttpRequest $request) {
		if ($this->key) {
		  $request->setUrl($request->getUrl() . ((strpos($request->getUrl(), '?') === false) ? '?' : '&'). 'key='.urlencode($this->key));
		}
		return $request;
	}

}

?>
