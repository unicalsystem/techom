<?php
class qCal_DateTime_Recur_Monthly extends qCal_DateTime_Recur {

	protected function doGetRecurrences($rules, $start, $end) {
	
		// do stuff!
	
	}

}