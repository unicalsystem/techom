<?php
/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */

class GoogleOffice365Suite_CTGoogleOffice365SuiteSyncGoogleContactsDataLog_View extends GoogleOffice365Suite_List_View {

    function checkPermission(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $paretTabName = $moduleModel->get('parent');
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $userPrivilegesModel = Users_Privileges_Model::getInstanceById($currentUser->getId());
        $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
        if($permission){
            return true;
        }
    }
    
	function process(Vtiger_Request $request) {
        global $current_user, $adb, $list_max_entries_per_page;

        $moduleName = $request->getModule();
        $qualifiedModuleName = $request->getModule(false);


        if (isset($_GET["page"])) {
            $pageStart = $_GET["page"]; 
        } else{ 
            $pageStart = 1;
        }

        $startFrom = ($pageStart-1) * $list_max_entries_per_page;
        
        $getGoogleCalendarLogQuery = 'SELECT * FROM `ctgoogleoffice365suite_synccontacts_synclog`
            INNER JOIN vtiger_contactdetails ON vtiger_contactdetails.contactid=ctgoogleoffice365suite_synccontacts_synclog.vtiger_contact_id
            INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid=vtiger_contactdetails.contactid  ';

        if (( isset( $_REQUEST['search_text'] ) && $_REQUEST['search_text'] != '' )) {
            if($current_user->is_admin == 'on' || $current_user->is_admin == 1){
                $getGoogleCalendarLogQuery .= ' WHERE ' . $_REQUEST['search_field'] . ' LIKE \'%'. $_REQUEST['search_text'].'%\' AND vtiger_crmentity.deleted = 0 ORDER BY crmid DESC LIMIT '.$startFrom.', '.$list_max_entries_per_page;
            }else{
                $getGoogleCalendarLogQuery .= ' WHERE ' . $_REQUEST['search_field'] . ' LIKE \'%'. $_REQUEST['search_text'].'%\' AND vtiger_crmentity.deleted = 0 ORDER BY crmid DESC LIMIT '.$startFrom.', '.$list_max_entries_per_page;
            }
        }else{
            if($current_user->is_admin == 'on' || $current_user->is_admin == 1){
                $getGoogleCalendarLogQuery .= 'WHERE vtiger_crmentity.deleted = 0 ORDER BY crmid DESC LIMIT '.$startFrom.', '.$list_max_entries_per_page;
            }else{
                $getGoogleCalendarLogQuery .= "WHERE vtiger_crmentity.deleted = 0 AND vtiger_crmentity.smownerid = ".$current_user->id." ORDER BY crmid DESC LIMIT ".$startFrom.", ".$list_max_entries_per_page;
            }
        }
        // echo "<pre>";print_r($getGoogleCalendarLogQuery);exit;
        $viewer = $this->getViewer($request);
        $viewer->assign('PAGE_START',$pageStart);
        $viewer->assign('PAGE_END', $list_max_entries_per_page);
        $viewer->assign('START_RANGE', $startRange);
        $viewer->assign('EVENT_URL','index.php?module=Calendar&view=Detail&record=');
        $viewer->assign('LOG_URL','index.php?module=CTGoogleCalendar&view=CTGoogleCalendarLog');
        $viewer->view( 'CTGoogleOffice365SuiteSyncGoogleContactsDataLog.tpl', $qualifiedModuleName);
    }

    /**
    * Function to get the list of Script models to be included
    * @param Vtiger_Request $request
    * @return <Array> - List of Vtiger_JsScript_Model instances
    */
    public function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            "modules.CTGoogleCalendar.resources.List"
        );

        $jsScriptInstances     = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }

    /**
    * Function to get Css files for this page
    */
    public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/GoogleOffice365Suite/resources/css/GoogleOffice365Suite.css",
          );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }
}

?>
