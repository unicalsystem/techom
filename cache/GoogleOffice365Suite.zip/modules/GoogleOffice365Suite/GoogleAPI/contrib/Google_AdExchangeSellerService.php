<?php
/**
 *
 * @ IonCube v8.3 Loader By DoraemonPT
 * @ PHP 5.3
 * @ Decoder version : 1.0.0.7
 * @ Author     : DoraemonPT
 * @ Release on : 09.05.2014
 * @ Website    : http://EasyToYou.eu
 *
 **/

class google_AccountsServiceResource extends Google_ServiceResource {
	/**
	 * Get information about the selected Ad Exchange account. (accounts.get)
	 *
	 * @param string $accountId Account to get information about. Tip: 'myaccount' is a valid ID.
	 * @param array $optParams Optional parameters.
	 * @return google_Account
	 */
	function get($accountId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
		}

		return new google_Account( $data );
	}
}

class google_AdclientsServiceResource extends Google_ServiceResource {
	/**
	 * List all ad clients in this Ad Exchange account. (adclients.list)
	 *
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of ad clients to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad clients. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_AdClients
	 */
	function listAdclients($optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = $params = array(  );

		if ($this->useObjects(  )) {
		}

		return new google_AdClients( $data );
	}
}

class google_AdunitsServiceResource extends Google_ServiceResource {
	/**
	 * Gets the specified ad unit in the specified ad client. (adunits.get)
	 *
	 * @param string $adClientId Ad client for which to get the ad unit.
	 * @param string $adUnitId Ad unit to retrieve.
	 * @param array $optParams Optional parameters.
	 * @return google_AdUnit
	 */
	function get($adClientId, $adUnitId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'adUnitId' => $adUnitId );
		$params = array_merge( $params, $optParams );
		$data = $this->__call( 'get', array( $params ) );

		if ($this->useObjects(  )) {
			new google_AdUnit;
		}

		( $data );
		return ;
	}

	/**
	 * List all ad units in the specified ad client for this Ad Exchange account.
	 * (adunits.list)
	 *
	 * @param string $adClientId Ad client for which to list ad units.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param bool includeInactive Whether to include inactive ad units. Default: true.
	 * @opt_param string maxResults The maximum number of ad units to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad units. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_AdUnits
	 */
	function listAdunits($adClientId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_AdUnits;
			$data;
		}

		(  );
		return ;
	}
}

class google_AdunitsCustomchannelsServiceResource extends Google_ServiceResource {
	/**
	 * List all custom channels which the specified ad unit belongs to.
	 * (customchannels.list)
	 *
	 * @param string $adClientId Ad client which contains the ad unit.
	 * @param string $adUnitId Ad unit for which to list custom channels.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of custom channels to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through custom channels. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_CustomChannels
	 */
	function listAdunitsCustomchannels($adClientId, $adUnitId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'adUnitId' => $adUnitId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_CustomChannels;
		}

		( $data );
		return ;
	}
}

class google_AlertsServiceResource extends Google_ServiceResource {
	/**
	 * List the alerts for this Ad Exchange account. (alerts.list)
	 *
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string locale The locale to use for translating alert messages. The account locale will be used if this is not supplied. The AdSense default (English) will be used if the supplied locale is invalid or unsupported.
	 * @return google_Alerts
	 */
	function listAlerts($optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = $params = array(  );
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_Alerts;
		}

		( $data );
		return ;
	}
}

class google_CustomchannelsServiceResource extends Google_ServiceResource {
	/**
	 * Get the specified custom channel from the specified ad client.
	 * (customchannels.get)
	 *
	 * @param string $adClientId Ad client which contains the custom channel.
	 * @param string $customChannelId Custom channel to retrieve.
	 * @param array $optParams Optional parameters.
	 * @return google_CustomChannel
	 */
	function get($adClientId, $customChannelId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'customChannelId' => $customChannelId );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = array_merge( $params, $optParams );

		if ($this->useObjects(  )) {
			new google_CustomChannel;
		}

		( $data );
		return ;
	}

	/**
	 * List all custom channels in the specified ad client for this Ad Exchange
	 * account. (customchannels.list)
	 *
	 * @param string $adClientId Ad client for which to list custom channels.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of custom channels to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through custom channels. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_CustomChannels
	 */
	function listCustomchannels($adClientId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
		}

		return new google_CustomChannels( $data );
	}
}

class google_CustomchannelsAdunitsServiceResource extends Google_ServiceResource {
	/**
	 * List all ad units in the specified custom channel. (adunits.list)
	 *
	 * @param string $adClientId Ad client which contains the custom channel.
	 * @param string $customChannelId Custom channel for which to list ad units.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param bool includeInactive Whether to include inactive ad units. Default: true.
	 * @opt_param string maxResults The maximum number of ad units to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad units. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_AdUnits
	 */
	function listCustomchannelsAdunits($adClientId, $customChannelId, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = $params = array( 'adClientId' => $adClientId, 'customChannelId' => $customChannelId );

		if ($this->useObjects(  )) {
			google_AdUnits;
		}

		return new ( $data );
	}
}

class google_MetadataServiceResource extends Google_ServiceResource {
}

class google_MetadataDimensionsServiceResource extends Google_ServiceResource {
	/**
	 * List the metadata for the dimensions available to this AdExchange account.
	 * (dimensions.list)
	 *
	 * @param array $optParams Optional parameters.
	 * @return google_Metadata
	 */
	function listMetadataDimensions($optParams = array(  )) {
		$params = array(  );
		array_merge( $params, $optParams );
		$this->__call( 'list', array( $params ) );
		$data = $params = ;

		if ($this->useObjects(  )) {
		}

		return new google_Metadata( $data );
	}
}

class google_MetadataMetricsServiceResource extends Google_ServiceResource {
	/**
	 * List the metadata for the metrics available to this AdExchange account.
	 * (metrics.list)
	 *
	 * @param array $optParams Optional parameters.
	 * @return google_Metadata
	 */
	function listMetadataMetrics($optParams = array(  )) {
		$params = array(  );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_Metadata( $data );
		}

		return ;
	}
}

class google_PreferreddealsServiceResource extends Google_ServiceResource {
	/**
	 * Get information about the selected Ad Exchange Preferred Deal.
	 * (preferreddeals.get)
	 *
	 * @param string $dealId Preferred deal to get information about.
	 * @param array $optParams Optional parameters.
	 * @return google_PreferredDeal
	 */
	function get($dealId, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = $params = array( 'dealId' => $dealId );
		$this->__call( 'get', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_PreferredDeal;
		}

		( $data );
		return ;
	}

	/**
	 * List the preferred deals for this Ad Exchange account. (preferreddeals.list)
	 *
	 * @param array $optParams Optional parameters.
	 * @return google_PreferredDeals
	 */
	function listPreferreddeals($optParams = array(  )) {
		$params = array(  );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_PreferredDeals( $data );
		}

		return ;
	}
}

class google_ReportsServiceResource extends Google_ServiceResource {
	/**
	 * Generate an Ad Exchange report based on the report request sent in the query
	 * parameters. Returns the result as JSON; to retrieve output in CSV format
	 * specify "alt=csv" as a query parameter. (reports.generate)
	 *
	 * @param string $startDate Start of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param string $endDate End of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string dimension Dimensions to base the report on.
	 * @opt_param string filter Filters to be run on the report.
	 * @opt_param string locale Optional locale to use for translating report output to a local language. Defaults to "en_US" if not specified.
	 * @opt_param string maxResults The maximum number of rows of report data to return.
	 * @opt_param string metric Numeric columns to include in the report.
	 * @opt_param string sort The name of a dimension or metric to sort the resulting report on, optionally prefixed with "+" to sort ascending or "-" to sort descending. If no prefix is specified, the column is sorted ascending.
	 * @opt_param string startIndex Index of the first row of report data to return.
	 * @return google_Report
	 */
	function generate($startDate, $endDate, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'generate', array( $params ) );
		$data = $params = array( 'startDate' => $startDate, 'endDate' => $endDate );

		if ($this->useObjects(  )) {
		}

		return new google_Report( $data );
	}
}

class google_ReportsSavedServiceResource extends Google_ServiceResource {
	/**
	 * Generate an Ad Exchange report based on the saved report ID sent in the query
	 * parameters. (saved.generate)
	 *
	 * @param string $savedReportId The saved report to retrieve.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string locale Optional locale to use for translating report output to a local language. Defaults to "en_US" if not specified.
	 * @opt_param int maxResults The maximum number of rows of report data to return.
	 * @opt_param int startIndex Index of the first row of report data to return.
	 * @return google_Report
	 */
	function generate($savedReportId, $optParams = array(  )) {
		$params = array( 'savedReportId' => $savedReportId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'generate', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_Report( $data );
		}

		return ;
	}

	/**
	 * List all saved reports in this Ad Exchange account. (saved.list)
	 *
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param int maxResults The maximum number of saved reports to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through saved reports. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_SavedReports
	 */
	function listReportsSaved($optParams = array(  )) {
		$params = array(  );
		$params = array_merge( $params, $optParams );
		$data = $this->__call( 'list', array( $params ) );

		if ($this->useObjects(  )) {
			new google_SavedReports( $data );
		}

		return ;
	}
}

class google_UrlchannelsServiceResource extends Google_ServiceResource {
	/**
	 * List all URL channels in the specified ad client for this Ad Exchange
	 * account. (urlchannels.list)
	 *
	 * @param string $adClientId Ad client for which to list URL channels.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of URL channels to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through URL channels. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return google_UrlChannels
	 */
	function listUrlchannels($adClientId, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = $params = array( 'adClientId' => $adClientId );
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new google_UrlChannels( $data );
		}

		return ;
	}
}

class google_AdExchangeSellerService extends Google_Service {
	var $accounts = null;
	var $adclients = null;
	var $adunits = null;
	var $adunits_customchannels = null;
	var $alerts = null;
	var $customchannels = null;
	var $customchannels_adunits = null;
	var $metadata_dimensions = null;
	var $metadata_metrics = null;
	var $preferreddeals = null;
	var $reports = null;
	var $reports_saved = null;
	var $urlchannels = null;

	/**
	 * Constructs the internal representation of the AdExchangeSeller service.
	 *
	 * @param Google_Client $client
	 */
	function __construct($client) {
		$this->servicePath = 'adexchangeseller/v1.1/';
		$this->version = 'v1.1';
		$this->serviceName = 'adexchangeseller';
		$client->addService( $this->serviceName, $this->version );
		$this->accounts = new google_AccountsServiceResource( $this, $this->serviceName, 'accounts', json_decode( '{"methods": {"get": {"id": "adexchangeseller.accounts.get", "path": "accounts/{accountId}", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "Account"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->adclients = new google_AdclientsServiceResource( $this, $this->serviceName, 'adclients', json_decode( '{"methods": {"list": {"id": "adexchangeseller.adclients.list", "path": "adclients", "httpMethod": "GET", "parameters": {"maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdClients"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->adunits = new google_AdunitsServiceResource( $this, $this->serviceName, 'adunits', json_decode( '{"methods": {"get": {"id": "adexchangeseller.adunits.get", "path": "adclients/{adClientId}/adunits/{adUnitId}", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}, "list": {"id": "adexchangeseller.adunits.list", "path": "adclients/{adClientId}/adunits", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "includeInactive": {"type": "boolean", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdUnits"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->adunits_customchannels = new google_AdunitsCustomchannelsServiceResource( $this, $this->serviceName, 'customchannels', json_decode( '{"methods": {"list": {"id": "adexchangeseller.adunits.customchannels.list", "path": "adclients/{adClientId}/adunits/{adUnitId}/customchannels", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "CustomChannels"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->alerts = new google_AlertsServiceResource( $this, $this->serviceName, 'alerts', json_decode( '{"methods": {"list": {"id": "adexchangeseller.alerts.list", "path": "alerts", "httpMethod": "GET", "parameters": {"locale": {"type": "string", "location": "query"}}, "response": {"$ref": "Alerts"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->customchannels = new google_CustomchannelsServiceResource( $this, $this->serviceName, 'customchannels', json_decode( '{"methods": {"get": {"id": "adexchangeseller.customchannels.get", "path": "adclients/{adClientId}/customchannels/{customChannelId}", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "customChannelId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}, "list": {"id": "adexchangeseller.customchannels.list", "path": "adclients/{adClientId}/customchannels", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "CustomChannels"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->customchannels_adunits = new google_CustomchannelsAdunitsServiceResource( $this, $this->serviceName, 'adunits', json_decode( '{"methods": {"list": {"id": "adexchangeseller.customchannels.adunits.list", "path": "adclients/{adClientId}/customchannels/{customChannelId}/adunits", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "customChannelId": {"type": "string", "required": true, "location": "path"}, "includeInactive": {"type": "boolean", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdUnits"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->metadata_dimensions = new google_MetadataDimensionsServiceResource( $this, $this->serviceName, 'dimensions', json_decode( '{"methods": {"list": {"id": "adexchangeseller.metadata.dimensions.list", "path": "metadata/dimensions", "httpMethod": "GET", "response": {"$ref": "Metadata"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->metadata_metrics = new google_MetadataMetricsServiceResource( $this, $this->serviceName, 'metrics', json_decode( '{"methods": {"list": {"id": "adexchangeseller.metadata.metrics.list", "path": "metadata/metrics", "httpMethod": "GET", "response": {"$ref": "Metadata"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->preferreddeals = new google_PreferreddealsServiceResource( $this, $this->serviceName, 'preferreddeals', json_decode( '{"methods": {"get": {"id": "adexchangeseller.preferreddeals.get", "path": "preferreddeals/{dealId}", "httpMethod": "GET", "parameters": {"dealId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "PreferredDeal"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}, "list": {"id": "adexchangeseller.preferreddeals.list", "path": "preferreddeals", "httpMethod": "GET", "response": {"$ref": "PreferredDeals"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->reports = new google_ReportsServiceResource( $this, $this->serviceName, 'reports', json_decode( '{"methods": {"generate": {"id": "adexchangeseller.reports.generate", "path": "reports", "httpMethod": "GET", "parameters": {"dimension": {"type": "string", "repeated": true, "location": "query"}, "endDate": {"type": "string", "required": true, "location": "query"}, "filter": {"type": "string", "repeated": true, "location": "query"}, "locale": {"type": "string", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "50000", "location": "query"}, "metric": {"type": "string", "repeated": true, "location": "query"}, "sort": {"type": "string", "repeated": true, "location": "query"}, "startDate": {"type": "string", "required": true, "location": "query"}, "startIndex": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "5000", "location": "query"}}, "response": {"$ref": "Report"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"], "supportsMediaDownload": true}}}', true ) );
		$this->reports_saved = new google_ReportsSavedServiceResource( $this, $this->serviceName, 'saved', json_decode( '{"methods": {"generate": {"id": "adexchangeseller.reports.saved.generate", "path": "reports/{savedReportId}", "httpMethod": "GET", "parameters": {"locale": {"type": "string", "location": "query"}, "maxResults": {"type": "integer", "format": "int32", "minimum": "0", "maximum": "50000", "location": "query"}, "savedReportId": {"type": "string", "required": true, "location": "path"}, "startIndex": {"type": "integer", "format": "int32", "minimum": "0", "maximum": "5000", "location": "query"}}, "response": {"$ref": "Report"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}, "list": {"id": "adexchangeseller.reports.saved.list", "path": "reports/saved", "httpMethod": "GET", "parameters": {"maxResults": {"type": "integer", "format": "int32", "minimum": "0", "maximum": "100", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "SavedReports"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
		$this->urlchannels = new google_UrlchannelsServiceResource( $this, $this->serviceName, 'urlchannels', json_decode( '{"methods": {"list": {"id": "adexchangeseller.urlchannels.list", "path": "adclients/{adClientId}/urlchannels", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "UrlChannels"}, "scopes": ["https://www.googleapis.com/auth/adexchange.seller", "https://www.googleapis.com/auth/adexchange.seller.readonly"]}}}', true ) );
	}
}

class google_Account extends Google_Model {
	var $id = null;
	var $kind = null;
	var $name = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}
}

class google_AdClient extends Google_Model {
	var $arcOptIn = null;
	var $id = null;
	var $kind = null;
	var $productCode = null;
	var $supportsReporting = null;

	function setArcOptIn($arcOptIn) {
		$this->arcOptIn = $arcOptIn;
	}

	function getArcOptIn() {
		return $this->arcOptIn;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setProductCode($productCode) {
		$this->productCode = $productCode;
	}

	function getProductCode() {
		return $this->productCode;
	}

	function setSupportsReporting($supportsReporting) {
		$this->supportsReporting = $supportsReporting;
	}

	function getSupportsReporting() {
		return $this->supportsReporting;
	}
}

class google_AdClients extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_AdClient';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'google_AdClient', 'google_AdClients::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class google_AdUnit extends Google_Model {
	var $code = null;
	var $id = null;
	var $kind = null;
	var $name = null;
	var $status = null;

	function setCode($code) {
		$this->code = $code;
	}

	function getCode() {
		return $this->code;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setStatus($status) {
		$this->status = $status;
	}

	function getStatus() {
		return $this->status;
	}
}

class google_AdUnits extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_AdUnit';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'google_AdUnit', 'google_AdUnits::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class google_Alert extends Google_Model {
	var $id = null;
	var $kind = null;
	var $message = null;
	var $severity = null;
	var $type = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setMessage($message) {
		$this->message = $message;
	}

	function getMessage() {
		return $this->message;
	}

	function setSeverity($severity) {
		$this->severity = $severity;
	}

	function getSeverity() {
		return $this->severity;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}
}

class google_Alerts extends Google_Model {
	private $__itemsType = 'Google_Alert';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;

	function setItems($items) {
		$this->assertIsArray( $items, 'google_Alert', 'google_Alerts::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class google_CustomChannel extends Google_Model {
	var $code = null;
	var $id = null;
	var $kind = null;
	var $name = null;
	private $__targetingInfoType = 'Google_CustomChannelTargetingInfo';
	private $__targetingInfoDataType = '';
	var $targetingInfo = null;

	function setCode($code) {
		$this->code = $code;
	}

	function getCode() {
		return $this->code;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setTargetingInfo($targetingInfo) {
		$this->targetingInfo = $targetingInfo;
	}

	function getTargetingInfo() {
		return $this->targetingInfo;
	}
}

class google_CustomChannelTargetingInfo extends Google_Model {
	var $adsAppearOn = null;
	var $description = null;
	var $location = null;
	var $siteLanguage = null;

	function setAdsAppearOn($adsAppearOn) {
		$this->adsAppearOn = $adsAppearOn;
	}

	function getAdsAppearOn() {
		return $this->adsAppearOn;
	}

	function setDescription($description) {
		$this->description = $description;
	}

	function getDescription() {
		return $this->description;
	}

	function setLocation($location) {
		$this->location = $location;
	}

	function getLocation() {
		return $this->location;
	}

	function setSiteLanguage($siteLanguage) {
		$this->siteLanguage = $siteLanguage;
	}

	function getSiteLanguage() {
		return $this->siteLanguage;
	}
}

class google_CustomChannels extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_CustomChannel';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'google_CustomChannel', 'google_CustomChannels::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class google_Metadata extends Google_Model {
	private $__itemsType = 'Google_ReportingMetadataEntry';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;

	function setItems($items) {
		$this->assertIsArray( $items, 'google_ReportingMetadataEntry', 'google_Metadata::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class google_PreferredDeal extends Google_Model {
	var $advertiserName = null;
	var $buyerNetworkName = null;
	var $currencyCode = null;
	var $endTime = null;
	var $fixedCpm = null;
	var $id = null;
	var $kind = null;
	var $startTime = null;

	function setAdvertiserName($advertiserName) {
		$this->advertiserName = $advertiserName;
	}

	function getAdvertiserName() {
		return $this->advertiserName;
	}

	function setBuyerNetworkName($buyerNetworkName) {
		$this->buyerNetworkName = $buyerNetworkName;
	}

	function getBuyerNetworkName() {
		return $this->buyerNetworkName;
	}

	function setCurrencyCode($currencyCode) {
		$this->currencyCode = $currencyCode;
	}

	function getCurrencyCode() {
		return $this->currencyCode;
	}

	function setEndTime($endTime) {
		$this->endTime = $endTime;
	}

	function getEndTime() {
		return $this->endTime;
	}

	function setFixedCpm($fixedCpm) {
		$this->fixedCpm = $fixedCpm;
	}

	function getFixedCpm() {
		return $this->fixedCpm;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setStartTime($startTime) {
		$this->startTime = $startTime;
	}

	function getStartTime() {
		return $this->startTime;
	}
}

class google_PreferredDeals extends Google_Model {
	private $__itemsType = 'Google_PreferredDeal';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;

	function setItems($items) {
		$this->assertIsArray( $items, 'google_PreferredDeal', 'google_PreferredDeals::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class google_Report extends Google_Model {
	var $averages = null;
	private $__headersType = 'Google_ReportHeaders';
	private $__headersDataType = 'array';
	var $headers = null;
	var $kind = null;
	var $rows = null;
	var $totalMatchedRows = null;
	var $totals = null;
	var $warnings = null;

	function setAverages($averages) {
		$this->assertIsArray( $averages, 'google_string', 'google_Report::setAverages' );
		$this->averages = $averages;
	}

	function getAverages() {
		return $this->averages;
	}

	function setHeaders($headers) {
		$this->assertIsArray( $headers, 'google_ReportHeaders', 'google_Report::setHeaders' );
		$this->headers = $headers;
	}

	function getHeaders() {
		return $this->headers;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setRows($rows) {
		$this->assertIsArray( $rows, 'google_string', 'google_Report::setRows' );
		$this->rows = $rows;
	}

	function getRows() {
		return $this->rows;
	}

	function setTotalMatchedRows($totalMatchedRows) {
		$this->totalMatchedRows = $totalMatchedRows;
	}

	function getTotalMatchedRows() {
		return $this->totalMatchedRows;
	}

	function setTotals($totals) {
		$this->assertIsArray( $totals, 'google_string', 'google_Report::setTotals' );
		$this->totals = $totals;
	}

	function getTotals() {
		return $this->totals;
	}

	function setWarnings($warnings) {
		$this->assertIsArray( $warnings, 'google_string', 'google_Report::setWarnings' );
		$this->warnings = $warnings;
	}

	function getWarnings() {
		return $this->warnings;
	}
}

class google_ReportHeaders extends Google_Model {
	var $currency = null;
	var $name = null;
	var $type = null;

	function setCurrency($currency) {
		$this->currency = $currency;
	}

	function getCurrency() {
		return $this->currency;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}
}

class google_ReportingMetadataEntry extends Google_Model {
	var $compatibleDimensions = null;
	var $compatibleMetrics = null;
	var $id = null;
	var $kind = null;
	var $requiredDimensions = null;
	var $requiredMetrics = null;
	var $supportedProducts = null;

	function setCompatibleDimensions($compatibleDimensions) {
		$this->assertIsArray( $compatibleDimensions, 'google_string', 'google_ReportingMetadataEntry::setCompatibleDimensions' );
		$this->compatibleDimensions = $compatibleDimensions;
	}

	function getCompatibleDimensions() {
		return $this->compatibleDimensions;
	}

	function setCompatibleMetrics($compatibleMetrics) {
		$this->assertIsArray( $compatibleMetrics, 'google_string', 'google_ReportingMetadataEntry::setCompatibleMetrics' );
		$this->compatibleMetrics = $compatibleMetrics;
	}

	function getCompatibleMetrics() {
		return $this->compatibleMetrics;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setRequiredDimensions($requiredDimensions) {
		$this->assertIsArray( $requiredDimensions, 'google_string', 'google_ReportingMetadataEntry::setRequiredDimensions' );
		$this->requiredDimensions = $requiredDimensions;
	}

	function getRequiredDimensions() {
		return $this->requiredDimensions;
	}

	function setRequiredMetrics($requiredMetrics) {
		$this->assertIsArray( $requiredMetrics, 'google_string', 'google_ReportingMetadataEntry::setRequiredMetrics' );
		$this->requiredMetrics = $requiredMetrics;
	}

	function getRequiredMetrics() {
		return $this->requiredMetrics;
	}

	function setSupportedProducts($supportedProducts) {
		$this->assertIsArray( $supportedProducts, 'google_string', 'google_ReportingMetadataEntry::setSupportedProducts' );
		$this->supportedProducts = $supportedProducts;
	}

	function getSupportedProducts() {
		return $this->supportedProducts;
	}
}

class google_SavedReport extends Google_Model {
	var $id = null;
	var $kind = null;
	var $name = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}
}

class google_SavedReports extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_SavedReport';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'google_SavedReport', 'google_SavedReports::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class google_UrlChannel extends Google_Model {
	var $id = null;
	var $kind = null;
	var $urlPattern = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setUrlPattern($urlPattern) {
		$this->urlPattern = $urlPattern;
	}

	function getUrlPattern() {
		return $this->urlPattern;
	}
}

class google_UrlChannels extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_UrlChannel';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'google_UrlChannel', 'google_UrlChannels::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

?>
