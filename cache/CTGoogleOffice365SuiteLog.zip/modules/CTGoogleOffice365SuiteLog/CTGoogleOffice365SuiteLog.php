<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

include_once 'modules/Vtiger/CRMEntity.php';

class CTGoogleOffice365SuiteLog extends Vtiger_CRMEntity {
	var $table_name = 'vtiger_ctgoogleoffice365suitelog';
	var $table_index= 'ctgoogleoffice365suitelogid';

	var $customFieldTable = Array('vtiger_ctgoogleoffice365suitelogcf', 'ctgoogleoffice365suitelogid');

	var $tab_name = Array('vtiger_crmentity', 'vtiger_ctgoogleoffice365suitelog', 'vtiger_ctgoogleoffice365suitelogcf');

	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_ctgoogleoffice365suitelog' => 'ctgoogleoffice365suitelogid',
		'vtiger_ctgoogleoffice365suitelogcf'=>'ctgoogleoffice365suitelogid');

	var $list_fields = Array (
		'CTGoogleOffice365SuiteLog No' => Array('ctgoogleoffice365suitelog', 'ctgoogleoffice365suitelog_no'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array (
		'CTGoogleOffice365SuiteLog No' => 'ctgoogleoffice365suitelog_no',
		'Assigned To' => 'assigned_user_id',
	);

	var $list_link_field = 'ctgoogleoffice365suitelog_no';

	var $search_fields = Array(
		'CTGoogleOffice365SuiteLog No' => Array('ctgoogleoffice365suitelog', 'ctgoogleoffice365suitelog_no'),
		'Assigned To' => Array('vtiger_crmentity','assigned_user_id'),
	);
	var $search_fields_name = Array (
		'CTGoogleOffice365SuiteLog No' => 'ctgoogleoffice365suitelog_no',
		'Assigned To' => 'assigned_user_id',
	);

	var $popup_fields = Array ('ctgoogleoffice365suitelog_no');

	var $def_basicsearch_col = 'ctgoogleoffice365suitelog_no';

	var $def_detailview_recname = 'ctgoogleoffice365suitelog_no';

	var $mandatory_fields = Array('ctgoogleoffice365suitelog_no','assigned_user_id');

	var $default_order_by = 'ctgoogleoffice365suitelog_no';
	var $default_sort_order='ASC';

	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($moduleName, $eventType) {
		global $adb;
 		if($eventType == 'module.postinstall') {
 			 self::checkWebServiceEntry();
			// TODO Handle actions after this module is installed.
		} else if($eventType == 'module.disabled') {
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			 self::checkWebServiceEntry();
			// TODO Handle actions after this module is updated.
		}
 	}

 	static function checkWebServiceEntry() {
        global $log;
        $log->debug("Entering checkWebServiceEntry() method....");
        global $adb;
        $sql       =  "SELECT count(id) AS cnt FROM vtiger_ws_entity WHERE name = 'GoogleOffice365Suite'";
        $result     = $adb->query($sql);
        if($adb->num_rows($result) > 0)
        {
            $no = $adb->query_result($result, 0, 'cnt');
            if($no == 0)
            {
                $tabid = $adb->getUniqueID("vtiger_ws_entity");
                $ws_entitySql = "INSERT INTO vtiger_ws_entity ( id, name, handler_path, handler_class, ismodule ) VALUES".
                          " (?, 'GoogleOffice365Suite','include/Webservices/VtigerModuleOperation.php', 'VtigerModuleOperation' , 1)";
                $res = $adb->pquery($ws_entitySql, array($tabid));
                $log->debug("Entered Record in vtiger WS entity ");
            }
        }
        $log->debug("Exiting checkWebServiceEntry() method....");
    }
}