<?php
/*******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
  ******************************************************************************/

class GoogleOffice365Suite_CTGoogleOffice365SuiteSyncGoogleContactsMappings_View extends Vtiger_List_View{
    
    /** 
    * Constructor which will set the column_fields in this object
    **/
    function __construct(){
        parent::__construct();
        $this->exposeMethod('getMappingConditions');
    }

    /** 
    * Function which will used to invoke functions
    **/
    public function process(Vtiger_Request $request){
        $mode = $request->get('mode');
        if (!empty($mode)) {
            $this->invokeExposedMethod($mode, $request);
            return;
        }
    }

    /** 
    * Function which will used to invoke Field Mapping
    **/
    function getMappingConditions(Vtiger_Request $request){
        global $current_user;
        $userId = $current_user->id;
        $moduleName = $request->getModule();
        $selectedModuleName = $request->get('sourceModule');
        $cvId = $request->get('cvId');

        $googleContactsFieldMapping = GoogleOffice365Suite_Record_Model::getGoogleContactsMapping($userId, $selectedModuleName);
        $moduleModel = Vtiger_Module_Model::getInstance($selectedModuleName);

        $googleContactsFields = array(
            'salutationtype' => array(
                    'name' => 'gd:namePrefix'
                ),
            'firstname' => array(
                    'name' => 'gd:givenName'
                ),
            'lastname' => array(
                    'name' => 'gd:familyName'
                ),
            'title' => array(
                    'name' => 'gd:orgTitle'
                ),
            'organizationname' => array(
                    'name' => 'gd:orgName'
                ),
            'birthday' => array(
                    'name' => 'gContact:birthday'
                ),  
            'email' => array(
                'name' => 'gd:email',
                'types' => array('home','work','custom')
                ),
            'phone' => array(
                'name' => 'gd:phoneNumber',
                'types' => array('mobile','home','work','main','work_fax','home_fax','pager','custom')
                ),
            'address' => array(
                'name' => 'gd:structuredPostalAddress',
                'types' => array('home','work','custom')
            ),
            'date' => array(
                'name' => 'gContact:event',
                'types' => array('anniversary','custom')
            ),
            'description' => array(
                'name' => 'content'
            ),
            'custom' => array(
                'name' => 'gContact:userDefinedField'
            ),
            'url' => array(
                'name' => 'gContact:website',
                'types' => array('profile','blog','home-page','work','custom')
            )
        ); 

        $recordStructureInstance = Vtiger_RecordStructure_Model::getInstanceForModule($moduleModel);
        // $test = GoogleOffice365Suite_Record_Model::getMappingFieldDropDown($moduleModel);
        
        $recordStructure = $recordStructureInstance->getStructure();
        $viewer = $this->getViewer($request);
        $viewer->assign('GOOGLECONTACTSFIELDS', $googleContactsFields);
        $viewer->assign('RECORD_STRUCTURE', $recordStructure);
        $viewer->assign('CVID', $cvId);
        $viewer->assign('CUSTOM_VIEWS', CustomView_Record_Model::getAllByGroup($selectedModuleName));
        $viewer->assign('PRIMARY_MODULE_NAME', $selectedModuleName);
        $viewer->assign('GOOGLECONTACTSFIELDMAPPING', $googleContactsFieldMapping);
        $viewer->assign('MODULE', $moduleName);
        $viewer->view('CTGoogleOffice365SuiteSyncGoogleContactMappingConditions.tpl', $moduleName);
    }

    /**
    * Function to get Css files for this page
    */
    public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/GoogleOffice365Suite/resources/css/GoogleOffice365Suite.css",
          );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }
}
?>