<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
include_once 'modules/Vtiger/CRMEntity.php';
class GoogleOffice365Suite extends Vtiger_CRMEntity {
	var $table_name = 'vtiger_googleoffice365suite';
	var $table_index= 'googleoffice365suiteid';
	var $customFieldTable = Array('vtiger_googleoffice365suitecf', 'googleoffice365suiteid');
	var $tab_name = Array('vtiger_crmentity', 'vtiger_googleoffice365suite', 'vtiger_googleoffice365suitecf');
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_googleoffice365suite' => 'googleoffice365suiteid',
		'vtiger_googleoffice365suitecf'=>'googleoffice365suiteid');
	var $list_fields = Array (
		'GoogleOffice365Suite No' => Array('googleoffice365suite', 'googleoffice365suite_no'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array (
		'GoogleOffice365Suite No' => 'googleoffice365suite_no',
		'Assigned To' => 'assigned_user_id',
	);
	var $list_link_field = 'googleoffice365suite_no';
	var $search_fields = Array(
		'GoogleOffice365Suite No' => Array('googleoffice365suite', 'googleoffice365suite_no'),
		'Assigned To' => Array('vtiger_crmentity','assigned_user_id'),
	);
	var $search_fields_name = Array (
		'GoogleOffice365Suite No' => 'googleoffice365suite_no',
		'Assigned To' => 'assigned_user_id',
	);
	var $popup_fields = Array ('googleoffice365suite_no');
	var $def_basicsearch_col = 'googleoffice365suite_no';
	var $def_detailview_recname = 'googleoffice365suite_no';
	var $mandatory_fields = Array('googleoffice365suite_no','assigned_user_id');
	var $default_order_by = 'googleoffice365suite_no';
	var $default_sort_order='ASC';
	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($moduleName, $eventType) {
		global $adb;
 		if($eventType == 'module.postinstall') {
 			self::checkEnable();
            self::checkWebServiceEntry();
            self::installTokenGenerateFile();  
			// TODO Handle actions after this module is installed.
		} else if($eventType == 'module.disabled') {
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
			self::installTokenGenerateFile();
		} else if($eventType == 'module.postupdate') {
			self::checkEnable();
            self::checkWebServiceEntry();
            self::installTokenGenerateFile();
			// TODO Handle actions after this module is updated.
		}
 	}

 	static function checkWebServiceEntry() {
        global $log;
        $log->debug("Entering checkWebServiceEntry() method....");
        global $adb;
        $sql       =  "SELECT count(id) AS cnt FROM vtiger_ws_entity WHERE name = 'GoogleOffice365Suite'";
        $result     = $adb->query($sql);
        if($adb->num_rows($result) > 0)
        {
            $no = $adb->query_result($result, 0, 'cnt');
            if($no == 0)
            {
                $tabid = $adb->getUniqueID("vtiger_ws_entity");
                $ws_entitySql = "INSERT INTO vtiger_ws_entity ( id, name, handler_path, handler_class, ismodule ) VALUES".
                          " (?, 'GoogleOffice365Suite','include/Webservices/VtigerModuleOperation.php', 'VtigerModuleOperation' , 1)";
                $res = $adb->pquery($ws_entitySql, array($tabid));
                $log->debug("Entered Record in vtiger WS entity ");
            }
        }
        $log->debug("Exiting checkWebServiceEntry() method....");
    }

    static function checkEnable() {
        global $adb;
 
        $adb->pquery("INSERT INTO `ctgoogleoffice365suite_outlooksynccontacts_fieldmapping` (`fieldmappingid`, `user_id`, `selected_module`, `vtiger_fields`, `outlook_fields`, `editable`) VALUES (1, 0, 'Contacts', 'lastname', 'givenName', 0);",array());

        $adb->pquery("INSERT INTO `ctgoogleoffice365suite_outlooksynccontacts_fieldmapping` (`fieldmappingid`, `user_id`, `selected_module`, `vtiger_fields`, `outlook_fields`, `editable`) VALUES (2, 0, 'Accounts', 'accountname', 'givenName', 0);",array());
        $adb->pquery("INSERT INTO `ctgoogleoffice365suite_outlooksynccontacts_fieldmapping` (`fieldmappingid`, `user_id`, `selected_module`, `vtiger_fields`, `outlook_fields`, `editable`) VALUES (3, 0, 'Leads', 'lastname', 'givenName', 0);",array());
    }


    static function installTokenGenerateFile() {
        global $adb;
        $fileArr =array('getGoogleToken','getOfficeToken');
        foreach ($fileArr as $key => $filename) {
        	 $dest1 = $filename.".php";
             $source1 = "modules/GoogleOffice365Suite/".$filename.".php";
	         chmod($source1, 0777);
		        if (file_exists($source1)) {
		            copy($source1, $dest1);
		            chmod($dest1, 0777);
		        }
        }
       
    }
}

?>