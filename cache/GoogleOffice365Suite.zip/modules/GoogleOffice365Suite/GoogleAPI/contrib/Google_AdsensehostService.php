<?php
/**
 *
 * @ IonCube v8.3 Loader By DoraemonPT
 * @ PHP 5.3
 * @ Decoder version : 1.0.0.7
 * @ Author     : DoraemonPT
 * @ Release on : 09.05.2014
 * @ Website    : http://EasyToYou.eu
 *
 **/

class Google_AccountsServiceResource extends Google_ServiceResource {
	/**
	 * Get information about the selected associated AdSense account. (accounts.get)
	 *
	 * @param string $accountId Account to get information about.
	 * @param array $optParams Optional parameters.
	 * @return Google_Account
	 */
	function get($accountId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId );
		$params = array_merge( $params, $optParams );
		$data = $this->__call( 'get', array( $params ) );

		if ($this->useObjects(  )) {
		}

		return new Google_Account( $data );
	}

	/**
	 * List hosted accounts associated with this AdSense account by ad client id. (accounts.list)
	 *
	 * @param string $filterAdClientId Ad clients to list accounts for.
	 * @param array $optParams Optional parameters.
	 * @return Google_Accounts
	 */
	function listAccounts($filterAdClientId, $optParams = array(  )) {
		$params = array( 'filterAdClientId' => $filterAdClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_Accounts;
		}

		( $data );
		return ;
	}
}

class Google_AccountsAdclientsServiceResource extends Google_ServiceResource {
	/**
	 * Get information about one of the ad clients in the specified publisher's AdSense account.
	 * (adclients.get)
	 *
	 * @param string $accountId Account which contains the ad client.
	 * @param string $adClientId Ad client to get.
	 * @param array $optParams Optional parameters.
	 * @return Google_AdClient
	 */
	function get($accountId, $adClientId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_AdClient;
		}

		( $data );
		return ;
	}

	/**
	 * List all hosted ad clients in the specified hosted account. (adclients.list)
	 *
	 * @param string $accountId Account for which to list ad clients.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of ad clients to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad clients. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return Google_AdClients
	 */
	function listAccountsAdclients($accountId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId );
		array_merge( $params, $optParams );
		$this->__call( 'list', array( $params ) );
		$data = $params = ;

		if ($this->useObjects(  )) {
		}

		return new Google_AdClients( $data );
	}
}

class Google_AccountsAdunitsServiceResource extends Google_ServiceResource {
	/**
	 * Delete the specified ad unit from the specified publisher AdSense account. (adunits.delete)
	 *
	 * @param string $accountId Account which contains the ad unit.
	 * @param string $adClientId Ad client for which to get ad unit.
	 * @param string $adUnitId Ad unit to delete.
	 * @param array $optParams Optional parameters.
	 * @return Google_AdUnit
	 */
	function delete($accountId, $adClientId, $adUnitId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'adUnitId' => $adUnitId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'delete', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_AdUnit;
		}

		( $data );
		return ;
	}

	/**
	 * Get the specified host ad unit in this AdSense account. (adunits.get)
	 *
	 * @param string $accountId Account which contains the ad unit.
	 * @param string $adClientId Ad client for which to get ad unit.
	 * @param string $adUnitId Ad unit to get.
	 * @param array $optParams Optional parameters.
	 * @return Google_AdUnit
	 */
	function get($accountId, $adClientId, $adUnitId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'adUnitId' => $adUnitId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			Google_AdUnit;
		}

		return new ( $data );
	}

	/**
	 * Get ad code for the specified ad unit, attaching the specified host custom channels.
	 * (adunits.getAdCode)
	 *
	 * @param string $accountId Account which contains the ad client.
	 * @param string $adClientId Ad client with contains the ad unit.
	 * @param string $adUnitId Ad unit to get the code for.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string hostCustomChannelId Host custom channel to attach to the ad code.
	 * @return Google_AdCode
	 */
	function getAdCode($accountId, $adClientId, $adUnitId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'adUnitId' => $adUnitId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'getAdCode', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
		}

		return new Google_AdCode( $data );
	}

	/**
	 * Insert the supplied ad unit into the specified publisher AdSense account. (adunits.insert)
	 *
	 * @param string $accountId Account which will contain the ad unit.
	 * @param string $adClientId Ad client into which to insert the ad unit.
	 * @param Google_AdUnit $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_AdUnit
	 */
	function insert($accountId, $adClientId, $postBody, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'postBody' => $postBody );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'insert', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_AdUnit;
		}

		( $data );
		return ;
	}

	/**
	 * List all ad units in the specified publisher's AdSense account. (adunits.list)
	 *
	 * @param string $accountId Account which contains the ad client.
	 * @param string $adClientId Ad client for which to list ad units.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param bool includeInactive Whether to include inactive ad units. Default: true.
	 * @opt_param string maxResults The maximum number of ad units to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad units. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return Google_AdUnits
	 */
	function listAccountsAdunits($accountId, $adClientId, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_AdUnits;
		}

		( $data );
		return ;
	}

	/**
	 * Update the supplied ad unit in the specified publisher AdSense account. This method supports
	 * patch semantics. (adunits.patch)
	 *
	 * @param string $accountId Account which contains the ad client.
	 * @param string $adClientId Ad client which contains the ad unit.
	 * @param string $adUnitId Ad unit to get.
	 * @param Google_AdUnit $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_AdUnit
	 */
	function patch($accountId, $adClientId, $adUnitId, $postBody, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'adUnitId' => $adUnitId, 'postBody' => $postBody );
		$params = ;
		$this->__call( 'patch', array( $params ) );
		$data = array_merge( $params, $optParams );

		if ($this->useObjects(  )) {
			Google_AdUnit;
		}

		return new ( $data );
	}

	/**
	 * Update the supplied ad unit in the specified publisher AdSense account. (adunits.update)
	 *
	 * @param string $accountId Account which contains the ad client.
	 * @param string $adClientId Ad client which contains the ad unit.
	 * @param Google_AdUnit $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_AdUnit
	 */
	function update($accountId, $adClientId, $postBody, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'update', array( $params ) );
		$data = $params = array( 'accountId' => $accountId, 'adClientId' => $adClientId, 'postBody' => $postBody );

		if ($this->useObjects(  )) {
			new Google_AdUnit;
		}

		( $data );
		return ;
	}
}

class Google_AccountsReportsServiceResource extends Google_ServiceResource {
	/**
	 * Generate an AdSense report based on the report request sent in the query parameters. Returns the
	 * result as JSON; to retrieve output in CSV format specify "alt=csv" as a query parameter.
	 * (reports.generate)
	 *
	 * @param string $accountId Hosted account upon which to report.
	 * @param string $startDate Start of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param string $endDate End of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string dimension Dimensions to base the report on.
	 * @opt_param string filter Filters to be run on the report.
	 * @opt_param string locale Optional locale to use for translating report output to a local language. Defaults to "en_US" if not specified.
	 * @opt_param string maxResults The maximum number of rows of report data to return.
	 * @opt_param string metric Numeric columns to include in the report.
	 * @opt_param string sort The name of a dimension or metric to sort the resulting report on, optionally prefixed with "+" to sort ascending or "-" to sort descending. If no prefix is specified, the column is sorted ascending.
	 * @opt_param string startIndex Index of the first row of report data to return.
	 * @return Google_Report
	 */
	function generate($accountId, $startDate, $endDate, $optParams = array(  )) {
		$params = array( 'accountId' => $accountId, 'startDate' => $startDate, 'endDate' => $endDate );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'generate', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_Report;
		}

		( $data );
		return ;
	}
}

class Google_AdclientsServiceResource extends Google_ServiceResource {
	/**
	 * Get information about one of the ad clients in the Host AdSense account. (adclients.get)
	 *
	 * @param string $adClientId Ad client to get.
	 * @param array $optParams Optional parameters.
	 * @return Google_AdClient
	 */
	function get($adClientId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$this->__call( 'get', array( $params ) );
		$data = $params = ;

		if ($this->useObjects(  )) {
			Google_AdClient;
		}

		return new ( $data );
	}

	/**
	 * List all host ad clients in this AdSense account. (adclients.list)
	 *
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of ad clients to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through ad clients. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return Google_AdClients
	 */
	function listAdclients($optParams = array(  )) {
		$params = array(  );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
		}

		return new Google_AdClients( $data );
	}
}

class Google_AssociationsessionsServiceResource extends Google_ServiceResource {
	/**
	 * Create an association session for initiating an association with an AdSense user.
	 * (associationsessions.start)
	 *
	 * @param string $productCode Products to associate with the user.
	 * @param string $websiteUrl The URL of the user's hosted website.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string userLocale The preferred locale of the user.
	 * @opt_param string websiteLocale The locale of the user's hosted website.
	 * @return Google_AssociationSession
	 */
	function start($productCode, $websiteUrl, $optParams = array(  )) {
		$params = array( 'productCode' => $productCode, 'websiteUrl' => $websiteUrl );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'start', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_AssociationSession( $data );
		}

		return ;
	}

	/**
	 * Verify an association session after the association callback returns from AdSense signup.
	 * (associationsessions.verify)
	 *
	 * @param string $token The token returned to the association callback URL.
	 * @param array $optParams Optional parameters.
	 * @return Google_AssociationSession
	 */
	function verify($token, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'verify', array( $params ) );
		$data = $params = array( 'token' => $token );

		if ($this->useObjects(  )) {
			new Google_AssociationSession;
		}

		( $data );
		return ;
	}
}

class Google_CustomchannelsServiceResource extends Google_ServiceResource {
	/**
	 * Delete a specific custom channel from the host AdSense account. (customchannels.delete)
	 *
	 * @param string $adClientId Ad client from which to delete the custom channel.
	 * @param string $customChannelId Custom channel to delete.
	 * @param array $optParams Optional parameters.
	 * @return Google_CustomChannel
	 */
	function delete($adClientId, $customChannelId, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'delete', array( $params ) );
		$data = $params = array( 'adClientId' => $adClientId, 'customChannelId' => $customChannelId );

		if ($this->useObjects(  )) {
			new Google_CustomChannel;
		}

		( $data );
		return ;
	}

	/**
	 * Get a specific custom channel from the host AdSense account. (customchannels.get)
	 *
	 * @param string $adClientId Ad client from which to get the custom channel.
	 * @param string $customChannelId Custom channel to get.
	 * @param array $optParams Optional parameters.
	 * @return Google_CustomChannel
	 */
	function get($adClientId, $customChannelId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'customChannelId' => $customChannelId );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = array_merge( $params, $optParams );

		if ($this->useObjects(  )) {
			new Google_CustomChannel;
		}

		( $data );
		return ;
	}

	/**
	 * Add a new custom channel to the host AdSense account. (customchannels.insert)
	 *
	 * @param string $adClientId Ad client to which the new custom channel will be added.
	 * @param Google_CustomChannel $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_CustomChannel
	 */
	function insert($adClientId, $postBody, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'postBody' => $postBody );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'insert', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_CustomChannel( $data );
		}

		return ;
	}

	/**
	 * List all host custom channels in this AdSense account. (customchannels.list)
	 *
	 * @param string $adClientId Ad client for which to list custom channels.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of custom channels to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through custom channels. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return Google_CustomChannels
	 */
	function listCustomchannels($adClientId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
		}

		return new Google_CustomChannels( $data );
	}

	/**
	 * Update a custom channel in the host AdSense account. This method supports patch semantics.
	 * (customchannels.patch)
	 *
	 * @param string $adClientId Ad client in which the custom channel will be updated.
	 * @param string $customChannelId Custom channel to get.
	 * @param Google_CustomChannel $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_CustomChannel
	 */
	function patch($adClientId, $customChannelId, $postBody, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'customChannelId' => $customChannelId, 'postBody' => $postBody );
		array_merge( $params, $optParams );
		$this->__call( 'patch', array( $params ) );
		$data = $params = ;

		if ($this->useObjects(  )) {
			new Google_CustomChannel;
		}

		( $data );
		return ;
	}

	/**
	 * Update a custom channel in the host AdSense account. (customchannels.update)
	 *
	 * @param string $adClientId Ad client in which the custom channel will be updated.
	 * @param Google_CustomChannel $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_CustomChannel
	 */
	function update($adClientId, $postBody, $optParams = array(  )) {
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'update', array( $params ) );
		$data = $params = array( 'adClientId' => $adClientId, 'postBody' => $postBody );

		if ($this->useObjects(  )) {
			new Google_CustomChannel;
		}

		( $data );
		return ;
	}
}

class Google_ReportsServiceResource extends Google_ServiceResource {
	/**
	 * Generate an AdSense report based on the report request sent in the query parameters. Returns the
	 * result as JSON; to retrieve output in CSV format specify "alt=csv" as a query parameter.
	 * (reports.generate)
	 *
	 * @param string $startDate Start of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param string $endDate End of the date range to report on in "YYYY-MM-DD" format, inclusive.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string dimension Dimensions to base the report on.
	 * @opt_param string filter Filters to be run on the report.
	 * @opt_param string locale Optional locale to use for translating report output to a local language. Defaults to "en_US" if not specified.
	 * @opt_param string maxResults The maximum number of rows of report data to return.
	 * @opt_param string metric Numeric columns to include in the report.
	 * @opt_param string sort The name of a dimension or metric to sort the resulting report on, optionally prefixed with "+" to sort ascending or "-" to sort descending. If no prefix is specified, the column is sorted ascending.
	 * @opt_param string startIndex Index of the first row of report data to return.
	 * @return Google_Report
	 */
	function generate($startDate, $endDate, $optParams = array(  )) {
		$params = array( 'startDate' => $startDate, 'endDate' => $endDate );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'generate', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_Report;
		}

		( $data );
		return ;
	}
}

class Google_UrlchannelsServiceResource extends Google_ServiceResource {
	/**
	 * Delete a URL channel from the host AdSense account. (urlchannels.delete)
	 *
	 * @param string $adClientId Ad client from which to delete the URL channel.
	 * @param string $urlChannelId URL channel to delete.
	 * @param array $optParams Optional parameters.
	 * @return Google_UrlChannel
	 */
	function delete($adClientId, $urlChannelId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'urlChannelId' => $urlChannelId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'delete', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_UrlChannel;
		}

		( $data );
		return ;
	}

	/**
	 * Add a new URL channel to the host AdSense account. (urlchannels.insert)
	 *
	 * @param string $adClientId Ad client to which the new URL channel will be added.
	 * @param Google_UrlChannel $postBody
	 * @param array $optParams Optional parameters.
	 * @return Google_UrlChannel
	 */
	function insert($adClientId, $postBody, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId, 'postBody' => $postBody );
		$params = ;
		$this->__call( 'insert', array( $params ) );
		$data = array_merge( $params, $optParams );

		if ($this->useObjects(  )) {
			new Google_UrlChannel( $data );
		}

		return ;
	}

	/**
	 * List all host URL channels in the host AdSense account. (urlchannels.list)
	 *
	 * @param string $adClientId Ad client for which to list URL channels.
	 * @param array $optParams Optional parameters.
	 *
	 * @opt_param string maxResults The maximum number of URL channels to include in the response, used for paging.
	 * @opt_param string pageToken A continuation token, used to page through URL channels. To retrieve the next page, set this parameter to the value of "nextPageToken" from the previous response.
	 * @return Google_UrlChannels
	 */
	function listUrlchannels($adClientId, $optParams = array(  )) {
		$params = array( 'adClientId' => $adClientId );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'list', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_UrlChannels( $data );
		}

		return ;
	}
}

class Google_AdSenseHostService extends Google_Service {
	var $accounts = null;
	var $accounts_adclients = null;
	var $accounts_adunits = null;
	var $accounts_reports = null;
	var $adclients = null;
	var $associationsessions = null;
	var $customchannels = null;
	var $reports = null;
	var $urlchannels = null;

	/**
	 * Constructs the internal representation of the AdSenseHost service.
	 *
	 * @param Google_Client $client
	 */
	function __construct($client) {
		$this->servicePath = 'adsensehost/v4.1/';
		$this->version = 'v4.1';
		$this->serviceName = 'adsensehost';
		$client->addService( $this->serviceName, $this->version );
		$this->accounts = new Google_AccountsServiceResource( $this, $this->serviceName, 'accounts', json_decode( '{"methods": {"get": {"id": "adsensehost.accounts.get", "path": "accounts/{accountId}", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "Account"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.accounts.list", "path": "accounts", "httpMethod": "GET", "parameters": {"filterAdClientId": {"type": "string", "required": true, "repeated": true, "location": "query"}}, "response": {"$ref": "Accounts"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->accounts_adclients = new Google_AccountsAdclientsServiceResource( $this, $this->serviceName, 'adclients', json_decode( '{"methods": {"get": {"id": "adsensehost.accounts.adclients.get", "path": "accounts/{accountId}/adclients/{adClientId}", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "AdClient"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.accounts.adclients.list", "path": "accounts/{accountId}/adclients", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdClients"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->accounts_adunits = new Google_AccountsAdunitsServiceResource( $this, $this->serviceName, 'adunits', json_decode( '{"methods": {"delete": {"id": "adsensehost.accounts.adunits.delete", "path": "accounts/{accountId}/adclients/{adClientId}/adunits/{adUnitId}", "httpMethod": "DELETE", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "get": {"id": "adsensehost.accounts.adunits.get", "path": "accounts/{accountId}/adclients/{adClientId}/adunits/{adUnitId}", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "getAdCode": {"id": "adsensehost.accounts.adunits.getAdCode", "path": "accounts/{accountId}/adclients/{adClientId}/adunits/{adUnitId}/adcode", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "path"}, "hostCustomChannelId": {"type": "string", "repeated": true, "location": "query"}}, "response": {"$ref": "AdCode"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "insert": {"id": "adsensehost.accounts.adunits.insert", "path": "accounts/{accountId}/adclients/{adClientId}/adunits", "httpMethod": "POST", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}}, "request": {"$ref": "AdUnit"}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.accounts.adunits.list", "path": "accounts/{accountId}/adclients/{adClientId}/adunits", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}, "includeInactive": {"type": "boolean", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdUnits"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "patch": {"id": "adsensehost.accounts.adunits.patch", "path": "accounts/{accountId}/adclients/{adClientId}/adunits", "httpMethod": "PATCH", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}, "adUnitId": {"type": "string", "required": true, "location": "query"}}, "request": {"$ref": "AdUnit"}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "update": {"id": "adsensehost.accounts.adunits.update", "path": "accounts/{accountId}/adclients/{adClientId}/adunits", "httpMethod": "PUT", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "adClientId": {"type": "string", "required": true, "location": "path"}}, "request": {"$ref": "AdUnit"}, "response": {"$ref": "AdUnit"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->accounts_reports = new Google_AccountsReportsServiceResource( $this, $this->serviceName, 'reports', json_decode( '{"methods": {"generate": {"id": "adsensehost.accounts.reports.generate", "path": "accounts/{accountId}/reports", "httpMethod": "GET", "parameters": {"accountId": {"type": "string", "required": true, "location": "path"}, "dimension": {"type": "string", "repeated": true, "location": "query"}, "endDate": {"type": "string", "required": true, "location": "query"}, "filter": {"type": "string", "repeated": true, "location": "query"}, "locale": {"type": "string", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "50000", "location": "query"}, "metric": {"type": "string", "repeated": true, "location": "query"}, "sort": {"type": "string", "repeated": true, "location": "query"}, "startDate": {"type": "string", "required": true, "location": "query"}, "startIndex": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "5000", "location": "query"}}, "response": {"$ref": "Report"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->adclients = new Google_AdclientsServiceResource( $this, $this->serviceName, 'adclients', json_decode( '{"methods": {"get": {"id": "adsensehost.adclients.get", "path": "adclients/{adClientId}", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "AdClient"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.adclients.list", "path": "adclients", "httpMethod": "GET", "parameters": {"maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "AdClients"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->associationsessions = new Google_AssociationsessionsServiceResource( $this, $this->serviceName, 'associationsessions', json_decode( '{"methods": {"start": {"id": "adsensehost.associationsessions.start", "path": "associationsessions/start", "httpMethod": "GET", "parameters": {"productCode": {"type": "string", "required": true, "enum": ["AFC", "AFG", "AFMC", "AFS", "AFV"], "repeated": true, "location": "query"}, "userLocale": {"type": "string", "location": "query"}, "websiteLocale": {"type": "string", "location": "query"}, "websiteUrl": {"type": "string", "required": true, "location": "query"}}, "response": {"$ref": "AssociationSession"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "verify": {"id": "adsensehost.associationsessions.verify", "path": "associationsessions/verify", "httpMethod": "GET", "parameters": {"token": {"type": "string", "required": true, "location": "query"}}, "response": {"$ref": "AssociationSession"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->customchannels = new Google_CustomchannelsServiceResource( $this, $this->serviceName, 'customchannels', json_decode( '{"methods": {"delete": {"id": "adsensehost.customchannels.delete", "path": "adclients/{adClientId}/customchannels/{customChannelId}", "httpMethod": "DELETE", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "customChannelId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "get": {"id": "adsensehost.customchannels.get", "path": "adclients/{adClientId}/customchannels/{customChannelId}", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "customChannelId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "insert": {"id": "adsensehost.customchannels.insert", "path": "adclients/{adClientId}/customchannels", "httpMethod": "POST", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}}, "request": {"$ref": "CustomChannel"}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.customchannels.list", "path": "adclients/{adClientId}/customchannels", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "CustomChannels"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "patch": {"id": "adsensehost.customchannels.patch", "path": "adclients/{adClientId}/customchannels", "httpMethod": "PATCH", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "customChannelId": {"type": "string", "required": true, "location": "query"}}, "request": {"$ref": "CustomChannel"}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "update": {"id": "adsensehost.customchannels.update", "path": "adclients/{adClientId}/customchannels", "httpMethod": "PUT", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}}, "request": {"$ref": "CustomChannel"}, "response": {"$ref": "CustomChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->reports = new Google_ReportsServiceResource( $this, $this->serviceName, 'reports', json_decode( '{"methods": {"generate": {"id": "adsensehost.reports.generate", "path": "reports", "httpMethod": "GET", "parameters": {"dimension": {"type": "string", "repeated": true, "location": "query"}, "endDate": {"type": "string", "required": true, "location": "query"}, "filter": {"type": "string", "repeated": true, "location": "query"}, "locale": {"type": "string", "location": "query"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "50000", "location": "query"}, "metric": {"type": "string", "repeated": true, "location": "query"}, "sort": {"type": "string", "repeated": true, "location": "query"}, "startDate": {"type": "string", "required": true, "location": "query"}, "startIndex": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "5000", "location": "query"}}, "response": {"$ref": "Report"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
		$this->urlchannels = new Google_UrlchannelsServiceResource( $this, $this->serviceName, 'urlchannels', json_decode( '{"methods": {"delete": {"id": "adsensehost.urlchannels.delete", "path": "adclients/{adClientId}/urlchannels/{urlChannelId}", "httpMethod": "DELETE", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "urlChannelId": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "UrlChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "insert": {"id": "adsensehost.urlchannels.insert", "path": "adclients/{adClientId}/urlchannels", "httpMethod": "POST", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}}, "request": {"$ref": "UrlChannel"}, "response": {"$ref": "UrlChannel"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}, "list": {"id": "adsensehost.urlchannels.list", "path": "adclients/{adClientId}/urlchannels", "httpMethod": "GET", "parameters": {"adClientId": {"type": "string", "required": true, "location": "path"}, "maxResults": {"type": "integer", "format": "uint32", "minimum": "0", "maximum": "10000", "location": "query"}, "pageToken": {"type": "string", "location": "query"}}, "response": {"$ref": "UrlChannels"}, "scopes": ["https://www.googleapis.com/auth/adsensehost"]}}}', true ) );
	}
}

class Google_Account extends Google_Model {
	var $id = null;
	var $kind = null;
	var $name = null;
	var $status = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setStatus($status) {
		$this->status = $status;
	}

	function getStatus() {
		return $this->status;
	}
}

class Google_Accounts extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_Account';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'Google_Account', 'Google_Accounts::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class Google_AdClient extends Google_Model {
	var $arcOptIn = null;
	var $id = null;
	var $kind = null;
	var $productCode = null;
	var $supportsReporting = null;

	function setArcOptIn($arcOptIn) {
		$this->arcOptIn = $arcOptIn;
	}

	function getArcOptIn() {
		return $this->arcOptIn;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setProductCode($productCode) {
		$this->productCode = $productCode;
	}

	function getProductCode() {
		return $this->productCode;
	}

	function setSupportsReporting($supportsReporting) {
		$this->supportsReporting = $supportsReporting;
	}

	function getSupportsReporting() {
		return $this->supportsReporting;
	}
}

class Google_AdClients extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_AdClient';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'Google_AdClient', 'Google_AdClients::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class Google_AdCode extends Google_Model {
	var $adCode = null;
	var $kind = null;

	function setAdCode($adCode) {
		$this->adCode = $adCode;
	}

	function getAdCode() {
		return $this->adCode;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class Google_AdStyle extends Google_Model {
	private $__colorsType = 'Google_AdStyleColors';
	private $__colorsDataType = '';
	var $colors = null;
	var $corners = null;
	private $__fontType = 'Google_AdStyleFont';
	private $__fontDataType = '';
	var $font = null;
	var $kind = null;

	function setColors($colors) {
		$this->colors = $colors;
	}

	function getColors() {
		return $this->colors;
	}

	function setCorners($corners) {
		$this->corners = $corners;
	}

	function getCorners() {
		return $this->corners;
	}

	function setFont($font) {
		$this->font = $font;
	}

	function getFont() {
		return $this->font;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}
}

class Google_AdStyleColors extends Google_Model {
	var $background = null;
	var $border = null;
	var $text = null;
	var $title = null;
	var $url = null;

	function setBackground($background) {
		$this->background = $background;
	}

	function getBackground() {
		return $this->background;
	}

	function setBorder($border) {
		$this->border = $border;
	}

	function getBorder() {
		return $this->border;
	}

	function setText($text) {
		$this->text = $text;
	}

	function getText() {
		return $this->text;
	}

	function setTitle($title) {
		$this->title = $title;
	}

	function getTitle() {
		return $this->title;
	}

	function setUrl($url) {
		$this->url = $url;
	}

	function getUrl() {
		return $this->url;
	}
}

class Google_AdStyleFont extends Google_Model {
	var $family = null;
	var $size = null;

	function setFamily($family) {
		$this->family = $family;
	}

	function getFamily() {
		return $this->family;
	}

	function setSize($size) {
		$this->size = $size;
	}

	function getSize() {
		return $this->size;
	}
}

class Google_AdUnit extends Google_Model {
	var $code = null;
	private $__contentAdsSettingsType = 'Google_AdUnitContentAdsSettings';
	private $__contentAdsSettingsDataType = '';
	var $contentAdsSettings = null;
	private $__customStyleType = 'Google_AdStyle';
	private $__customStyleDataType = '';
	var $customStyle = null;
	var $id = null;
	var $kind = null;
	private $__mobileContentAdsSettingsType = 'Google_AdUnitMobileContentAdsSettings';
	private $__mobileContentAdsSettingsDataType = '';
	var $mobileContentAdsSettings = null;
	var $name = null;
	var $status = null;

	function setCode($code) {
		$this->code = $code;
	}

	function getCode() {
		return $this->code;
	}

	function setContentAdsSettings($contentAdsSettings) {
		$this->contentAdsSettings = $contentAdsSettings;
	}

	function getContentAdsSettings() {
		return $this->contentAdsSettings;
	}

	function setCustomStyle($customStyle) {
		$this->customStyle = $customStyle;
	}

	function getCustomStyle() {
		return $this->customStyle;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setMobileContentAdsSettings($mobileContentAdsSettings) {
		$this->mobileContentAdsSettings = $mobileContentAdsSettings;
	}

	function getMobileContentAdsSettings() {
		return $this->mobileContentAdsSettings;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setStatus($status) {
		$this->status = $status;
	}

	function getStatus() {
		return $this->status;
	}
}

class Google_AdUnitContentAdsSettings extends Google_Model {
	private $__backupOptionType = 'Google_AdUnitContentAdsSettingsBackupOption';
	private $__backupOptionDataType = '';
	var $backupOption = null;
	var $size = null;
	var $type = null;

	function setBackupOption($backupOption) {
		$this->backupOption = $backupOption;
	}

	function getBackupOption() {
		return $this->backupOption;
	}

	function setSize($size) {
		$this->size = $size;
	}

	function getSize() {
		return $this->size;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}
}

class Google_AdUnitContentAdsSettingsBackupOption extends Google_Model {
	var $color = null;
	var $type = null;
	var $url = null;

	function setColor($color) {
		$this->color = $color;
	}

	function getColor() {
		return $this->color;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}

	function setUrl($url) {
		$this->url = $url;
	}

	function getUrl() {
		return $this->url;
	}
}

class Google_AdUnitMobileContentAdsSettings extends Google_Model {
	var $markupLanguage = null;
	var $scriptingLanguage = null;
	var $size = null;
	var $type = null;

	function setMarkupLanguage($markupLanguage) {
		$this->markupLanguage = $markupLanguage;
	}

	function getMarkupLanguage() {
		return $this->markupLanguage;
	}

	function setScriptingLanguage($scriptingLanguage) {
		$this->scriptingLanguage = $scriptingLanguage;
	}

	function getScriptingLanguage() {
		return $this->scriptingLanguage;
	}

	function setSize($size) {
		$this->size = $size;
	}

	function getSize() {
		return $this->size;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}
}

class Google_AdUnits extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_AdUnit';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'Google_AdUnit', 'Google_AdUnits::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class Google_AssociationSession extends Google_Model {
	var $accountId = null;
	var $id = null;
	var $kind = null;
	var $productCodes = null;
	var $redirectUrl = null;
	var $status = null;
	var $userLocale = null;
	var $websiteLocale = null;
	var $websiteUrl = null;

	function setAccountId($accountId) {
		$this->accountId = $accountId;
	}

	function getAccountId() {
		return $this->accountId;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setProductCodes($productCodes) {
		$this->assertIsArray( $productCodes, 'Google_string', 'Google_AssociationSession::setProductCodes' );
		$this->productCodes = $productCodes;
	}

	function getProductCodes() {
		return $this->productCodes;
	}

	function setRedirectUrl($redirectUrl) {
		$this->redirectUrl = $redirectUrl;
	}

	function getRedirectUrl() {
		return $this->redirectUrl;
	}

	function setStatus($status) {
		$this->status = $status;
	}

	function getStatus() {
		return $this->status;
	}

	function setUserLocale($userLocale) {
		$this->userLocale = $userLocale;
	}

	function getUserLocale() {
		return $this->userLocale;
	}

	function setWebsiteLocale($websiteLocale) {
		$this->websiteLocale = $websiteLocale;
	}

	function getWebsiteLocale() {
		return $this->websiteLocale;
	}

	function setWebsiteUrl($websiteUrl) {
		$this->websiteUrl = $websiteUrl;
	}

	function getWebsiteUrl() {
		return $this->websiteUrl;
	}
}

class Google_CustomChannel extends Google_Model {
	var $code = null;
	var $id = null;
	var $kind = null;
	var $name = null;

	function setCode($code) {
		$this->code = $code;
	}

	function getCode() {
		return $this->code;
	}

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}
}

class Google_CustomChannels extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_CustomChannel';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'Google_CustomChannel', 'Google_CustomChannels::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

class Google_Report extends Google_Model {
	var $averages = null;
	private $__headersType = 'Google_ReportHeaders';
	private $__headersDataType = 'array';
	var $headers = null;
	var $kind = null;
	var $rows = null;
	var $totalMatchedRows = null;
	var $totals = null;
	var $warnings = null;

	function setAverages($averages) {
		$this->assertIsArray( $averages, 'Google_string', 'Google_Report::setAverages' );
		$this->averages = $averages;
	}

	function getAverages() {
		return $this->averages;
	}

	function setHeaders($headers) {
		$this->assertIsArray( $headers, 'Google_ReportHeaders', 'Google_Report::setHeaders' );
		$this->headers = $headers;
	}

	function getHeaders() {
		return $this->headers;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setRows($rows) {
		$this->assertIsArray( $rows, 'Google_string', 'Google_Report::setRows' );
		$this->rows = $rows;
	}

	function getRows() {
		return $this->rows;
	}

	function setTotalMatchedRows($totalMatchedRows) {
		$this->totalMatchedRows = $totalMatchedRows;
	}

	function getTotalMatchedRows() {
		return $this->totalMatchedRows;
	}

	function setTotals(&$totals) {
		$this->assertIsArray( $totals, 'Google_string', 'Google_Report::setTotals' );
		$this->totals = $totals;
	}

	function getTotals() {
		return $this->totals;
	}

	function setWarnings($warnings) {
		$this->assertIsArray( $warnings, 'Google_string', 'Google_Report::setWarnings' );
		$this->warnings = $warnings;
	}

	function getWarnings() {
		return $this->warnings;
	}
}

class Google_ReportHeaders extends Google_Model {
	var $currency = null;
	var $name = null;
	var $type = null;

	function setCurrency($currency) {
		$this->currency = $currency;
	}

	function getCurrency() {
		return $this->currency;
	}

	function setName($name) {
		$this->name = $name;
	}

	function getName() {
		return $this->name;
	}

	function setType($type) {
		$this->type = $type;
	}

	function getType() {
		return $this->type;
	}
}

class Google_UrlChannel extends Google_Model {
	var $id = null;
	var $kind = null;
	var $urlPattern = null;

	function setId($id) {
		$this->id = $id;
	}

	function getId() {
		return $this->id;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setUrlPattern($urlPattern) {
		$this->urlPattern = $urlPattern;
	}

	function getUrlPattern() {
		return $this->urlPattern;
	}
}

class Google_UrlChannels extends Google_Model {
	var $etag = null;
	private $__itemsType = 'Google_UrlChannel';
	private $__itemsDataType = 'array';
	var $items = null;
	var $kind = null;
	var $nextPageToken = null;

	function setEtag($etag) {
		$this->etag = $etag;
	}

	function getEtag() {
		return $this->etag;
	}

	function setItems($items) {
		$this->assertIsArray( $items, 'Google_UrlChannel', 'Google_UrlChannels::setItems' );
		$this->items = $items;
	}

	function getItems() {
		return $this->items;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setNextPageToken($nextPageToken) {
		$this->nextPageToken = $nextPageToken;
	}

	function getNextPageToken() {
		return $this->nextPageToken;
	}
}

?>
