<?php
/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */

require_once('modules/GoogleOffice365Suite/GoogleAPI/Google_Client.php' );
class GoogleOffice365Suite_CTGoogleOffice365SuiteSyncGoogleContactsTokenAuthorize_View extends Vtiger_Index_View {

	function checkPermission(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $paretTabName = $moduleModel->get('parent');
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $userPrivilegesModel = Users_Privileges_Model::getInstanceById($currentUser->getId());
        $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
        if($permission){
            return true;
        }
    }

	function process(Vtiger_Request $request) {
		global $site_URL,$adb,$current_user;

		if (substr( $site_URL, -1 ) != '/') {
			$site_URL .= '/';
		}

		$tableName = 'ctgoogleoffice365suite_synccontacts_configuration';
        $selectFieldsName = array("*");
        $whereData = array('user_id' => $current_user->id);
        $getGoogleContactsConfigurationData = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData($tableName, $selectFieldsName, $whereData);

        $clientId = $adb->query_result($getGoogleContactsConfigurationData, 0, 'client_id');
        $clientSecret = $adb->query_result($getGoogleContactsConfigurationData, 0, 'client_secret');
        $domainUrl = $adb->query_result($getGoogleContactsConfigurationData, 0, 'domain_url');
        $redirectUris = $adb->query_result($getGoogleContactsConfigurationData, 0, 'redirect_uris');
		$redirectUris = html_entity_decode($redirectUris);
	
		$client = new Google_Client();
		$client->setApplicationName('Google Contacts Sync Module');
		$client->setClientId($clientId);
		$client->setClientSecret($clientSecret);
		$client->setRedirectUri($redirectUris);
		$client->setScopes('https://www.google.com/m8/feeds');
		$client->setAccessType('offline');

		$sessionToken = '';
		$tokenTableName = 'ctgoogleoffice365suite_synccontacts_token';
        $selectFieldsName = array("token");
        $whereData = array('user_id' => $current_user->id);

        $getGoogleContactsTokenData = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData($tokenTableName, $selectFieldsName, $whereData);
		$nums = $adb->num_rows($getGoogleContactsTokenData);

		if (0 < $nums) {
			$sessionToken = $adb->query_result( $getGoogleContactsTokenData, 0,'token');
		}

		if(isset($_GET['code'])){
			$client->authenticate($_GET['code']);
			$sessionToken = $client->getAccessToken();
		}

		if ($sessionToken) {
			$userId = $current_user->id;
            $tokenAccess = html_entity_decode($sessionToken);
            $jsonEncodeAccessToken = json_decode($tokenAccess,true);
            $accessToken = $jsonEncodeAccessToken['access_token'];
        
	        $getContactsGroup = GoogleOffice365Suite_Record_Model::getResponseFromGoogleContacts($accessToken);
	        $contactsGroup = json_decode($getContactsGroup,true);

	        $calendarListTableName = 'ctgoogleoffice365suite_synccontacts_contactsgroup';
            $where = array('user_id' => $userId);
            $deleteData = GoogleOffice365Suite_Record_Model::deleteGoogleOffice365SuiteData($calendarListTableName, $where);

	        $contactsGroupData = array();
	        foreach ($contactsGroup['contactGroups'] as $key => $value) {
			 	$insertData = array('google_contacts_id' => "'".$value['resourceName']."'", 'summary' => "'".$value['formattedName']."'",'user_id' => $userId);

	            $insertCTGoogleOffice365SuiteData = GoogleOffice365Suite_Record_Model::insertGoogleOffice365Suite($calendarListTableName, $insertData);
	        }

			$_SESSION['token'] = $client->getAccessToken();
		}
		if ($sessionToken == '') {
			$authUrl = $client->createAuthUrl();
			header( 'Location: ' . $authUrl);
			exit;
		}	

		if (0 < $adb->num_rows($getGoogleContactsTokenData)) {
			$updateData = array('token' => "'".$sessionToken."'");
			$where = array('user_id' => "'".$current_user->id."'");
			$updateCTGoogleOffice365Suite = GoogleOffice365Suite_Record_Model::updateGoogleOffice365Suite($tokenTableName, $updateData, $where);
		} else {
			$insertData = array('user_id' => "'".$current_user->id."'", 'token' => "'".$sessionToken."'");

	        $insertCTGoogleOffice365Suite = GoogleOffice365Suite_Record_Model::insertGoogleOffice365Suite($tokenTableName, $insertData);
		}

		$redirect = $site_URL . 'index.php?module=GoogleOffice365Suite&view=CTGoogleOffice365SuiteSyncGoogleContactsGenerateToken&app=SALES';
		header( 'Location: ' . $redirect );
	}
}

