<?php
/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */

include_once 'includes/main/WebUI.php';
require_once('include/utils/utils.php');
require_once('modules/GoogleOffice365Suite/GoogleAPI/Google_Client.php');

function checkToken($sessionToken) {
	global $adb, $current_user;

	$configurationQuery = $adb->query( 'SELECT * FROM `ctgoogleoffice365suite_synccontacts_configuration` WHERE user_id = "'.$current_user->id.'"',array());
	if ($adb->num_rows($configurationQuery) > 0) {
		$client_id = $adb->query_result( $configurationQuery, 0, 'client_id');
		$client_secret = $adb->query_result($configurationQuery, 0, 'client_secret');
		$redirect_uris = $adb->query_result($configurationQuery, 0, 'redirect_uris');
		
		$client = new Google_Client();
		$client->setApplicationName( 'Google Calendar Sync Module' );
		$client->setClientId($client_id);
		$client->setClientSecret($client_secret);
		$client->setRedirectUri($redirect_uris);
		$client->setAccessType("offline");
		$client->setScopes('https://www.googleapis.com/auth/contacts');
		
		$tokenCalendar = $adb->query( 'SELECT * FROM `ctgoogleoffice365suite_synccontacts_token` WHERE user_id = "'.$current_user->id.'"',array());
		$accessToken = $adb->query_result($tokenCalendar, 0, 'token');
		$tokenAccess = html_entity_decode($accessToken);
		$jsonEncodeAccessToken = json_decode($tokenAccess,true);
		$jsonDecodeAccessToken = array("access_token" => $jsonEncodeAccessToken['access_token'], "refresh_token" => $jsonEncodeAccessToken['refresh_token'], "token_type" => $jsonEncodeAccessToken['token_type'], "expires_in" => $jsonEncodeAccessToken['expires_in'], "id_token" =>  $jsonEncodeAccessToken['access_token'], "created" => $jsonEncodeAccessToken['created']);
		
		$client->setAccessToken(json_encode($jsonDecodeAccessToken));
		if ($client->isAccessTokenExpired()) {
			$client->refreshToken($jsonEncodeAccessToken['refresh_token']);
			$refreshAccessToken = $client->getAccessToken();
			
			$tokenTableName = 'ctgoogleoffice365suite_synccontacts_token';
			$updateData = array('token' => "'".$refreshAccessToken."'");
			$where = array('user_id' => "'".$current_user->id."'");
			$updateCTGoogleOffice365Suite = GoogleOffice365Suite_Record_Model::updateGoogleOffice365Suite($tokenTableName, $updateData, $where);
		} 
	}
	return $client;
}

function checkGoogleCalendarToken($sessionToken) {
	global $adb, $current_user;

	$configurationQuery = $adb->query( 'SELECT * FROM `ctgoogleoffice365suite_synccalendar_configuration` WHERE user_id = "'.$current_user->id.'"',array());
	if ($adb->num_rows($configurationQuery) > 0) {
		$client_id = $adb->query_result( $configurationQuery, 0, 'client_id');
		$client_secret = $adb->query_result($configurationQuery, 0, 'client_secret');
		$redirect_uris = $adb->query_result($configurationQuery, 0, 'redirect_uris');
		
		$client = new Google_Client();
		$client->setApplicationName( 'Google Calendar Sync Module' );
		$client->setClientId("819644135058-kcmf6pvbcqtbicufib6t4uan475d39d9.apps.googleusercontent.com");
		$client->setClientSecret("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");
		// $client->setRedirectUri($redirect_uris);
		$client->setAccessType("offline");
		$client->setScopes( 'http://www.google.com/calendar/feeds/');
		
		$tokenCalendar = $adb->query( 'SELECT * FROM `ctgoogleoffice365suite_synccalendar_token` WHERE user_id = "'.$current_user->id.'"',array());
		$accessToken = $adb->query_result($tokenCalendar, 0, 'token');
		// echo 
		$tokenAccess = html_entity_decode($accessToken);
		$jsonEncodeAccessToken = json_decode($tokenAccess,true);
		$jsonDecodeAccessToken = array("access_token" => $jsonEncodeAccessToken['access_token'], "refresh_token" => $jsonEncodeAccessToken['refresh_token'], "token_type" => $jsonEncodeAccessToken['token_type'], "expires_in" => $jsonEncodeAccessToken['expires_in'], "id_token" =>  $jsonEncodeAccessToken['access_token'], "created" => $jsonEncodeAccessToken['created']);
		
		$client->setAccessToken(json_encode($jsonDecodeAccessToken));
		/*$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,'https://www.googleapis.com/oauth2/v1/tokeninfo?access_token='.$jsonEncodeAccessToken['access_token']);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		curl_close($ch);
		echo "<pre>";print_r($result);exit;*/
		if ($client->isAccessTokenExpired()) {
			$client->refreshToken($jsonEncodeAccessToken['refresh_token']);
			$refreshAccessToken = $client->getAccessToken();
			
			$tokenTableName = 'ctgoogleoffice365suite_synccalendar_token';
			$updateData = array('token' => "'".$refreshAccessToken."'");
			$where = array('user_id' => "'".$current_user->id."'");
			$updateCTGoogleOffice365Suite = GoogleOffice365Suite_Record_Model::updateGoogleOffice365Suite($tokenTableName, $updateData, $where);
		} 

	}
	return $client;
}

?>

