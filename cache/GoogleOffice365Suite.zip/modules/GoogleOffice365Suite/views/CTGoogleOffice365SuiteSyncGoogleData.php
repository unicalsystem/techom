<?php
/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */

class GoogleOffice365Suite_CTGoogleOffice365SuiteSyncGoogleData_View extends Vtiger_List_View {

    function checkPermission(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $paretTabName = $moduleModel->get('parent');
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $userPrivilegesModel = Users_Privileges_Model::getInstanceById($currentUser->getId());
        $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
        if($permission){
            return true;
        }
    }

    /**
    * Function to process the Edit View
    * @param Vtiger_Request $request
    */
    function process(Vtiger_Request $request) {
        global $current_user, $adb;
        $moduleName = $request->getModule();
        $qualifiedModuleName = $request->getModule(false);

        $tableName = 'ctgoogleoffice365suite_syncgoogle_enableautosync';
        $selectFieldsName = array("*");
        $whereData = array('user_id' => $current_user->id);
        $getGoogleCalendarAutoSyncData = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData($tableName, $selectFieldsName, $whereData);

        $enableSyncEvent = $adb->query_result($getGoogleCalendarAutoSyncData, 0, 'enablesync_event');
        $BatchEvent = $adb->query_result($getGoogleCalendarAutoSyncData, 0, 'batch_event');
        $enableSyncContact = $adb->query_result($getGoogleCalendarAutoSyncData, 0, 'enablesync_contact');
        $batchContact = $adb->query_result($getGoogleCalendarAutoSyncData, 0, 'batch_contact');
        

        // Login Google User
        $googleUserEmail = GoogleOffice365Suite_Record_Model::getUserEmail();

        $googleCalendarSetting = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('ctgoogleoffice365suite_synccalendar_settings', array("*"), $whereData);
        $CalendarSettingStatus = $adb->num_rows($googleCalendarSetting);

        $googleContactSetting = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('ctgoogleoffice365suite_synccontacts_contactsgroup', array("*"), $whereData);
        $ContactSettingStatus = $adb->num_rows($googleContactSetting);

        $whereCalendar = array('name' => '"CTGoogleOffice365SuiteSyncGoogleCalendarSyncToVtiger"');
        $whereContact = array('name' => '"CTGoogleOffice365SuiteSyncGoogleContactsSyncToVtiger"');
        $selectFieldsName = array("frequency");
        $googleCalendarCronSetting = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('vtiger_cron_task', $selectFieldsName, $whereCalendar);
        $googleContactCronSetting = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('vtiger_cron_task', $selectFieldsName, $whereContact);
        if ($adb->num_rows( $googleCalendarCronSetting ) > 0) {
            $cronFrequencyEvent = $adb->query_result($googleCalendarCronSetting, 0, 'frequency');
        }
        if ($adb->num_rows( $googleContactCronSetting ) > 0) {
            $cronFrequencyContact = $adb->query_result($googleContactCronSetting, 0, 'frequency');
        }
        $getGoogleCalendarDashboardURl = GoogleOffice365Suite_Record_Model::getGoogleCalendarDashboardURL();

        $frequencyEvent = $cronFrequencyEvent / 60;
        $frequencyContact = $cronFrequencyContact / 60;
        $viewer = $this->getViewer($request);
        $viewer->assign('GOOGLECALENDARDASHBOARD',$getGoogleCalendarDashboardURl);
        $viewer->assign('GOOGLEUSER', $googleUserEmail);
        $viewer->assign('MODULE', $moduleName);
        $viewer->assign('USER_ID', $current_user->id);
        $viewer->assign('IS_ADMIN', $current_user->is_admin);
        $viewer->assign('EVENT_ENABLESYNC', $enableSyncEvent);
        $viewer->assign('CALENDARBATCH', $BatchEvent);
        $viewer->assign('EVENT_FREQUENCY', $frequencyEvent);
        $viewer->assign('CONTACT_ENABLESYNC', $enableSyncContact);
        $viewer->assign('CAL_SETTING_STATUS',$CalendarSettingStatus);
        $viewer->assign('CON_SETTING_STATUS',$ContactSettingStatus);
        $viewer->assign('CONTACTBATCH', $batchContact);
        $viewer->assign('CONTACT_FREQUENCY', $frequencyContact);
        $viewer->assign('GOOGLECONTACTSLOG', 'index.php?module=CTGoogleOffice365SuiteLog&view=List');
        $viewer->view('CTGoogleOffice365SuiteSyncGoogleData.tpl', $qualifiedModuleName);
    }

    /**
    * Function to get the list of Script models to be included
    * @param Vtiger_Request $request
    * @return <Array> - List of Vtiger_JsScript_Model instances
    */
    public function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            "modules.GoogleOffice365Suite.resources.CTGoogleOffice365Common",
            "modules.GoogleOffice365Suite.resources.CTGoogleSyncCommon",
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }

    /**
    * Function to get Css files for this page
    */
    public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/GoogleOffice365Suite/resources/css/GoogleOffice365Suite.css",
          );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }
}

?>
