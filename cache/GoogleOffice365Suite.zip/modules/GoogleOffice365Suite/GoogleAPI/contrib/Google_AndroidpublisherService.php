<?php
/**
 *
 * @ IonCube v8.3 Loader By DoraemonPT
 * @ PHP 5.3
 * @ Decoder version : 1.0.0.7
 * @ Author     : DoraemonPT
 * @ Release on : 09.05.2014
 * @ Website    : http://EasyToYou.eu
 *
 **/

class Google_InapppurchasesServiceResource extends Google_ServiceResource {
	/**
	 * Checks the purchase and consumption status of an inapp item. (inapppurchases.get)
	 *
	 * @param string $packageName The package name of the application the inapp product was sold in (for example, 'com.some.thing').
	 * @param string $productId The inapp product SKU (for example, 'com.some.thing.inapp1').
	 * @param string $token The token provided to the user's device when the inapp product was purchased.
	 * @param array $optParams Optional parameters.
	 * @return Google_InappPurchase
	 */
	function get($packageName, $productId, $token, $optParams = array(  )) {
		$params = array( 'packageName' => $packageName, 'productId' => $productId, 'token' => $token );
		$params = array_merge( $params, $optParams );
		$data = $this->__call( 'get', array( $params ) );

		if ($this->useObjects(  )) {
			new Google_InappPurchase;
		}

		( $data );
		return ;
	}
}

class Google_PurchasesServiceResource extends Google_ServiceResource {
	/**
	 * Cancels a user's subscription purchase. The subscription remains valid until its expiration time.
	 * (purchases.cancel)
	 *
	 * @param string $packageName The package name of the application for which this subscription was purchased (for example, 'com.some.thing').
	 * @param string $subscriptionId The purchased subscription ID (for example, 'monthly001').
	 * @param string $token The token provided to the user's device when the subscription was purchased.
	 * @param array $optParams Optional parameters.
	 */
	function cancel($packageName, $subscriptionId, $token, $optParams = array(  )) {
		$params = array( 'packageName' => $packageName, 'subscriptionId' => $subscriptionId, 'token' => $token );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'cancel', array( $params ) );
		$data = ;
		return $data;
	}

	/**
	 * Checks whether a user's subscription purchase is valid and returns its expiry time.
	 * (purchases.get)
	 *
	 * @param string $packageName The package name of the application for which this subscription was purchased (for example, 'com.some.thing').
	 * @param string $subscriptionId The purchased subscription ID (for example, 'monthly001').
	 * @param string $token The token provided to the user's device when the subscription was purchased.
	 * @param array $optParams Optional parameters.
	 * @return Google_SubscriptionPurchase
	 */
	function get($packageName, $subscriptionId, $token, $optParams = array(  )) {
		$params = array( 'packageName' => $packageName, 'subscriptionId' => $subscriptionId, 'token' => $token );
		array_merge( $params, $optParams );
		$params = ;
		$this->__call( 'get', array( $params ) );
		$data = ;

		if ($this->useObjects(  )) {
			new Google_SubscriptionPurchase;
		}

		( $data );
		return ;
	}
}

class Google_AndroidPublisherService extends Google_Service {
	var $inapppurchases = null;
	var $purchases = null;

	/**
	 * Constructs the internal representation of the AndroidPublisher service.
	 *
	 * @param Google_Client $client
	 */
	function __construct($client) {
		$this->servicePath = 'androidpublisher/v1.1/applications/';
		$this->version = 'v1.1';
		$this->serviceName = 'androidpublisher';
		$client->addService( $this->serviceName, $this->version );
		$this->inapppurchases = new Google_InapppurchasesServiceResource( $this, $this->serviceName, 'inapppurchases', json_decode( '{"methods": {"get": {"id": "androidpublisher.inapppurchases.get", "path": "{packageName}/inapp/{productId}/purchases/{token}", "httpMethod": "GET", "parameters": {"packageName": {"type": "string", "required": true, "location": "path"}, "productId": {"type": "string", "required": true, "location": "path"}, "token": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "InappPurchase"}}}}', true ) );
		$this->purchases = new Google_PurchasesServiceResource( $this, $this->serviceName, 'purchases', json_decode( '{"methods": {"cancel": {"id": "androidpublisher.purchases.cancel", "path": "{packageName}/subscriptions/{subscriptionId}/purchases/{token}/cancel", "httpMethod": "POST", "parameters": {"packageName": {"type": "string", "required": true, "location": "path"}, "subscriptionId": {"type": "string", "required": true, "location": "path"}, "token": {"type": "string", "required": true, "location": "path"}}}, "get": {"id": "androidpublisher.purchases.get", "path": "{packageName}/subscriptions/{subscriptionId}/purchases/{token}", "httpMethod": "GET", "parameters": {"packageName": {"type": "string", "required": true, "location": "path"}, "subscriptionId": {"type": "string", "required": true, "location": "path"}, "token": {"type": "string", "required": true, "location": "path"}}, "response": {"$ref": "SubscriptionPurchase"}}}}', true ) );
	}
}

class Google_InappPurchase extends Google_Model {
	var $consumptionState = null;
	var $developerPayload = null;
	var $kind = null;
	var $purchaseState = null;
	var $purchaseTime = null;

	function setConsumptionState($consumptionState) {
		$this->consumptionState = $consumptionState;
	}

	function getConsumptionState() {
		return $this->consumptionState;
	}

	function setDeveloperPayload($developerPayload) {
		$this->developerPayload = $developerPayload;
	}

	function getDeveloperPayload() {
		return $this->developerPayload;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setPurchaseState($purchaseState) {
		$this->purchaseState = $purchaseState;
	}

	function getPurchaseState() {
		return $this->purchaseState;
	}

	function setPurchaseTime($purchaseTime) {
		$this->purchaseTime = $purchaseTime;
	}

	function getPurchaseTime() {
		return $this->purchaseTime;
	}
}

class Google_SubscriptionPurchase extends Google_Model {
	var $autoRenewing = null;
	var $initiationTimestampMsec = null;
	var $kind = null;
	var $validUntilTimestampMsec = null;

	function setAutoRenewing($autoRenewing) {
		$this->autoRenewing = $autoRenewing;
	}

	function getAutoRenewing() {
		return $this->autoRenewing;
	}

	function setInitiationTimestampMsec($initiationTimestampMsec) {
		$this->initiationTimestampMsec = $initiationTimestampMsec;
	}

	function getInitiationTimestampMsec() {
		return $this->initiationTimestampMsec;
	}

	function setKind($kind) {
		$this->kind = $kind;
	}

	function getKind() {
		return $this->kind;
	}

	function setValidUntilTimestampMsec($validUntilTimestampMsec) {
		$this->validUntilTimestampMsec = $validUntilTimestampMsec;
	}

	function getValidUntilTimestampMsec() {
		return $this->validUntilTimestampMsec;
	}
}

?>
