<?php
/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */

class GoogleOffice365Suite_CTGoogleOffice365SuiteSyncGoogleContactsGenerateToken_View extends Vtiger_List_View {

    function checkPermission(Vtiger_Request $request) {
        return true;
    }

    /**
    * Function to process the List View
    * @param Vtiger_Request $request
    */
	function process(Vtiger_Request $request) {
        global $current_user, $adb;
        
        $moduleName = $request->getModule();
        $qualifiedModuleName = $request->getModule(false);
        $getGoogleContactsURL = GoogleOffice365Suite_Record_Model::getGoogleContactDashboardURL();
    
        $selectFieldsName = array("*");
        $whereData = array('user_id' => $current_user->id);

        $googleUserEmail = GoogleOffice365Suite_Record_Model::getUserEmail();

        // setContactGroups
        $setContactGroups = GoogleOffice365Suite_Record_Model::setGoogleContactsGroups($current_user->id);
        
        $googleContactsSetting = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('ctgoogleoffice365suite_synccontacts_settings', $selectFieldsName, $whereData);

        $contactgroupSelected = $adb->query_result($googleContactsSetting, 0, 'contactgroup_selected');
        $deletedFromGoogle = $adb->query_result($googleContactsSetting, 0,'deleted_from_google');
        $deletedFromVtiger = $adb->query_result($googleContactsSetting, 0, 'deleted_from_vtiger');
        $selectedModule = $adb->query_result($googleContactsSetting, 0,'selected_module');
        $selectedFilter = $adb->query_result($googleContactsSetting, 0, 'selected_cvid');

        $getContactsGroupData = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData('ctgoogleoffice365suite_synccontacts_contactsgroup', $selectFieldsName, $whereData);
        $contactsGroupNumOfRows = $adb->num_rows($getContactsGroupData);
        $googleContactsGroupData = array();
        for ($i=0; $i < $contactsGroupNumOfRows; $i++) { 
            $contactsGroupId = $adb->query_result($getContactsGroupData, $i, 'google_contacts_id');
            $contatsGroupName = $adb->query_result($getContactsGroupData, $i, 'summary');
            if($contactgroupSelected == $contactsGroupId){
                $contactGroupSelected[$contactsGroupId] = $contatsGroupName;
            }else{
                $googleContactsGroupData[$contactsGroupId] = $contatsGroupName;
            }
        }

        if(empty($contactGroupSelected)){
            $googleCalendarListIds = array_keys($googleContactsGroupData);
            $contactGroupSelected[$googleCalendarListIds['0']] = $googleContactsGroupData[$googleCalendarListIds['0']];
            unset($googleContactsGroupData[$googleCalendarListIds['0']]);
        }

        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $userPrivilegesModel = Users_Privileges_Model::getInstanceById($currentUser->getId());
        $modulePermission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());

        $tableName = 'ctgoogleoffice365suite_synccontacts_user_management';
        $selectFieldsName = array("*");
        $whereData = array('contact_limit' => '1', 'admin_user_id' => $current_user->id);
        $getGoogleCalendarUserData = GoogleOffice365Suite_Record_Model::getSelectedGoogleOffice365SuiteData($tableName, $selectFieldsName, $whereData);
        $availableUsers = get_user_array();
        $selectedUsersOption = array();
 
        $contactFolderLimit = 0;
        $count = $adb->num_rows($getGoogleCalendarUserData);
        if ($count > 0) {
            for($i=0;$i<$count;$i++){
                $userid = $adb->query_result($getGoogleCalendarUserData, $i, 'user_id');
                $selectedUsersOption[$userid] = $availableUsers[$userid];

                if($userid == $current_user->id){
                    $contactFolderLimit = $adb->query_result($getGoogleCalendarUserData, $i, 'contact_limit');
                }
            }
        }
        else{
           $selectedUsersOption[$current_user->id] = $availableUsers[$current_user->id]; 
           unset($availableUsers[$current_user->id]);        
        }
        

        foreach ($availableUsers as $key => $value) {
            if(!in_array($value, $selectedUsersOption)){
                $availableUser[$key] = $value;
            }
        }

        $modulesData = array('Contacts', 'Accounts', 'Leads');

        if($selectedModule == ''){
            $selectedModule = 'Leads';
        }

        $UserLimit = 0;        
        $viewer = $this->getViewer($request);
        $viewer->assign('MODULE', $moduleName);
        $viewer->assign('GOOGLECONTACTSURL', $getGoogleContactsURL);
        $viewer->assign('USER_LIMIT', $UserLimit);
        $viewer->assign('CALENDAR_DISABLED', $modulePermission);
        $viewer->assign('USER_ID', $current_user->id);
        $viewer->assign('GOOGLE_USEREMAIL', $googleUserEmail);
        $viewer->assign('CONTACTLIMIT', $contactFolderLimit);
        $viewer->assign('IS_ADMIN', $current_user->is_admin);
        $viewer->assign('MODULEDATA', $modulesData);
        $viewer->assign('SESSION_TOKEN_VALID', $tokenValid);
        $viewer->assign('CONTACTSGROUPDATA', $googleContactsGroupData);
        $viewer->assign('AVAILABLE_USERS', array_filter($availableUser));
        $viewer->assign('AUTHURL', $authURL);
        $viewer->assign('TOKENEXPIRED', $tokenExpired);
        $viewer->assign('SELECTED_USERS_OPTION',$selectedUsersOption);
        $viewer->assign('CONTACTGROUPSELECTED',$contactGroupSelected);
        $viewer->assign('DELETEDFROMGOOGLE',$deletedFromGoogle);
        $viewer->assign('DELETEDFROMVTIGER',$deletedFromVtiger);
        $viewer->assign('SELECTEDMODULE',$selectedModule);
        $viewer->assign('SELECTEDFILTER',$selectedFilter);
        $viewer->assign('UNINSTALLMODULE', 'index.php?module=CTGoogleCalendar&view=CTGoogleCalendarUninstall');
        $viewer->view('CTGoogleOffice365SuiteSyncGoogleContactsGenerateToken.tpl', $moduleName);
	}

    /**
    * Function to get the list of Script models to be included
    * @param Vtiger_Request $request
    * @return <Array> - List of Vtiger_JsScript_Model instances
    */
    public function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            "modules.GoogleOffice365Suite.resources.CTGoogleOffice365SuiteSyncGoogleContacts",
            "modules.GoogleOffice365Suite.resources.CTGoogleOffice365Common"
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }

    /**
    * Function to get Css files for this page
    */
    public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/GoogleOffice365Suite/resources/css/GoogleOffice365Suite.css",
          );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }
}

?>
